-- Named queries used by brain/memory.py. Each starts with "-- name: <name>" and holds exactly one statement.
-- Parameters look like :user.

-- name: upsert_user
INSERT INTO users (id, name) VALUES (:user, :name)
ON CONFLICT(id) DO UPDATE SET name = excluded.name;

-- name: latest_conversation
-- Reuse the newest conversation if it was active in the last six hours.
SELECT id FROM conversations
WHERE user_id = :user AND updated_at >= datetime('now', '-6 hours')
ORDER BY updated_at DESC, id DESC LIMIT 1;

-- name: new_conversation
INSERT INTO conversations (user_id, title) VALUES (:user, :title);

-- name: touch_conversation
UPDATE conversations SET updated_at = datetime('now') WHERE id = :id;

-- name: insert_message
INSERT INTO messages (conversation_id, user_id, role, content) VALUES (:conv, :user, :role, :content);

-- name: recent_messages
SELECT role, content, created_at FROM messages
WHERE conversation_id = :conv ORDER BY id DESC LIMIT :n;

-- name: insert_memory
INSERT OR IGNORE INTO memories (user_id, kind, text, importance) VALUES (:user, :kind, :text, :importance);

-- name: find_memory
SELECT id FROM memories WHERE user_id = :user AND kind = :kind AND text = :text;

-- name: insert_vec
INSERT OR REPLACE INTO memory_vec (memory_id, dim, val) VALUES (:id, :dim, :val);

-- name: insert_norm
INSERT OR REPLACE INTO memory_norm (memory_id, norm) VALUES (:id, :norm);

-- name: search_hybrid
-- Hybrid retrieval in one query: cosine similarity over the sparse vector index (60%),
-- BM25 keyword relevance (30%) and stored importance (10%). :qvec is a JSON list of [dim, value] pairs.
WITH q(dim, val) AS (
    SELECT json_extract(value, '$[0]'), json_extract(value, '$[1]') FROM json_each(:qvec)
),
vec AS (
    SELECT v.memory_id AS id, SUM(v.val * q.val) / (n.norm * :qnorm) AS cosine
    FROM memory_vec v
    JOIN q ON q.dim = v.dim
    JOIN memory_norm n ON n.memory_id = v.memory_id
    JOIN memories m ON m.id = v.memory_id
    WHERE m.user_id = :user
    GROUP BY v.memory_id
),
kw AS (
    SELECT rowid AS id, -bm25(memory_fts) AS bm FROM memory_fts WHERE memory_fts MATCH :fts
)
SELECT m.id, m.kind, m.text, m.created_at,
       COALESCE(vec.cosine, 0) * 0.6 + (COALESCE(kw.bm, 0) / (1.0 + COALESCE(kw.bm, 0))) * 0.3 + m.importance * 0.1 AS score
FROM memories m
LEFT JOIN vec ON vec.id = m.id
LEFT JOIN kw ON kw.id = m.id
WHERE m.user_id = :user AND (vec.id IS NOT NULL OR kw.id IS NOT NULL)
ORDER BY score DESC, m.id DESC
LIMIT :k;

-- name: touch_memory
UPDATE memories SET uses = uses + 1, last_used_at = datetime('now') WHERE id = :id AND user_id = :user;

-- name: list_memories
SELECT id, kind, text, importance, created_at, uses FROM memories
WHERE user_id = :user ORDER BY id DESC LIMIT :n;

-- name: delete_memory
DELETE FROM memories WHERE id = :id AND user_id = :user;

-- name: memory_stats
SELECT (SELECT COUNT(*) FROM memories WHERE user_id = :user) AS memories,
       (SELECT COUNT(*) FROM messages WHERE user_id = :user) AS messages,
       (SELECT COUNT(*) FROM conversations WHERE user_id = :user) AS conversations;

-- name: log_device
INSERT INTO device_log (user_id, device, command, ok, result) VALUES (:user, :device, :command, :ok, :result);

-- name: recent_device_log
SELECT device, command, ok, result, created_at FROM device_log ORDER BY id DESC LIMIT :n;
