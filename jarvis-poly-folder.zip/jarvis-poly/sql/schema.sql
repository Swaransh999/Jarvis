-- Jarvis memory: conversations, long-term memories, full-text search and a vector index. SQLite.
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    id          TEXT PRIMARY KEY,                     -- the login ID ("owner" or a Stripe customer ID)
    name        TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS conversations (
    id          INTEGER PRIMARY KEY,
    user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title       TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_conv_user ON conversations(user_id, updated_at DESC);

CREATE TABLE IF NOT EXISTS messages (
    id              INTEGER PRIMARY KEY,
    conversation_id INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    user_id         TEXT NOT NULL,
    role            TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
    content         TEXT NOT NULL,
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_msg_conv ON messages(conversation_id, id);

-- Long-term memory: facts, preferences, notes and past user messages worth recalling.
CREATE TABLE IF NOT EXISTS memories (
    id           INTEGER PRIMARY KEY,
    user_id      TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    kind         TEXT NOT NULL CHECK (kind IN ('fact', 'preference', 'note', 'message')),
    text         TEXT NOT NULL,
    importance   REAL NOT NULL DEFAULT 0.5 CHECK (importance BETWEEN 0 AND 1),
    created_at   TEXT NOT NULL DEFAULT (datetime('now')),
    last_used_at TEXT,
    uses         INTEGER NOT NULL DEFAULT 0,
    UNIQUE (user_id, kind, text)
);
CREATE INDEX IF NOT EXISTS idx_mem_user ON memories(user_id, created_at DESC);

-- Keyword search (BM25) over memory text.
CREATE VIRTUAL TABLE IF NOT EXISTS memory_fts USING fts5(text, content = 'memories', content_rowid = 'id');
CREATE TRIGGER IF NOT EXISTS memories_ai AFTER INSERT ON memories BEGIN
    INSERT INTO memory_fts(rowid, text) VALUES (new.id, new.text);
END;
CREATE TRIGGER IF NOT EXISTS memories_ad AFTER DELETE ON memories BEGIN
    INSERT INTO memory_fts(memory_fts, rowid, text) VALUES ('delete', old.id, old.text);
END;

-- Vector index: one row per non-zero dimension of each memory's embedding (sparse), plus its length.
CREATE TABLE IF NOT EXISTS memory_vec (
    memory_id INTEGER NOT NULL REFERENCES memories(id) ON DELETE CASCADE,
    dim       INTEGER NOT NULL,
    val       REAL    NOT NULL,
    PRIMARY KEY (memory_id, dim)
) WITHOUT ROWID;
CREATE INDEX IF NOT EXISTS idx_vec_dim ON memory_vec(dim);

CREATE TABLE IF NOT EXISTS memory_norm (
    memory_id INTEGER PRIMARY KEY REFERENCES memories(id) ON DELETE CASCADE,
    norm      REAL NOT NULL
);

-- Every device command Jarvis sends, for the dashboard and for safety review.
CREATE TABLE IF NOT EXISTS device_log (
    id         INTEGER PRIMARY KEY,
    user_id    TEXT NOT NULL,
    device     TEXT NOT NULL,
    command    TEXT NOT NULL,
    ok         INTEGER NOT NULL,
    result     TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
