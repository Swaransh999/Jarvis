// Device hub (C++17): IoT and robot devices with hard safety limits.
// Motion is simulated in a real-time tick loop; every command is clamped to the device's limits.
// The devices here are virtual. Replace the tick() body with real drivers for real hardware.
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <map>
#include <mutex>
#include <string>
#include <utility>
#include <vector>

namespace jrt {

inline std::string json_num(double v) {
    char buf[40];
    std::snprintf(buf, sizeof buf, "%.2f", v);
    return buf;
}
inline std::string json_str(const std::string& s) {
    std::string o = "\"";
    for (char c : s) {
        if (c == '"' || c == '\\') { o += '\\'; o += c; }
        else if (static_cast<unsigned char>(c) < 0x20) o += ' ';
        else o += c;
    }
    return o + "\"";
}
inline std::string json_err(const std::string& code) { return "{\"ok\":false,\"error\":" + json_str(code) + "}"; }

struct Prop {
    double value = 0, target = 0, min = 0, max = 1;
    double rate = 0;          // units per second; 0 means the value changes instantly
    bool readonly = false;
};

struct Device {
    std::string name, kind;
    bool safety = false;      // stopped by the emergency stop
    std::vector<std::pair<std::string, Prop>> props;
    Prop* find(const std::string& k) {
        for (auto& p : props) if (p.first == k) return &p.second;
        return nullptr;
    }
};

class Hub {
public:
    Hub() {
        add("light_living", "light", false, {{"on", mk(0, 0, 1, 0)}, {"level", mk(60, 0, 100, 400)}});
        add("thermostat", "thermostat", false, {{"setpoint", mk(22, 16, 30, 0)}, {"current", ro(21, 10, 35, 0.5)}});
        add("robot_arm", "robot_arm", true,
            {{"j1", mk(0, -90, 90, 60)}, {"j2", mk(0, 0, 135, 60)}, {"j3", mk(0, -45, 45, 60)}, {"gripper", mk(0, 0, 100, 120)}});
        add("door_lock", "lock", false, {{"locked", mk(1, 0, 1, 0)}});
    }

    // Advance the simulation by dt seconds.
    void tick(double dt) {
        std::lock_guard<std::mutex> g(m_);
        for (auto& d : devs_) {
            if (d.kind == "thermostat") d.find("current")->target = d.find("setpoint")->value;
            for (auto& kv : d.props) {
                Prop& p = kv.second;
                if (p.rate <= 0) continue;
                const double step = p.rate * dt, diff = p.target - p.value;
                p.value = std::fabs(diff) <= step ? p.target : p.value + (diff > 0 ? step : -step);
            }
        }
    }

    std::string state_json() {
        std::lock_guard<std::mutex> g(m_);
        std::string o = std::string("{\"ok\":true,\"estop\":") + (estop_ ? "true" : "false") + ",\"devices\":{";
        for (size_t i = 0; i < devs_.size(); i++) o += (i ? "," : "") + dev_json(devs_[i], true);
        return o + "}}";
    }

    std::string get_json(const std::string& name) {
        std::lock_guard<std::mutex> g(m_);
        Device* d = find(name);
        if (!d) return json_err("unknown_device");
        return "{\"ok\":true," + dev_json(*d, true).substr(0) + "}";
    }

    // Apply requested property values. Values outside the device limits are clamped and reported.
    std::string set(const std::string& name, const std::vector<std::pair<std::string, std::string>>& kv, bool confirm) {
        std::lock_guard<std::mutex> g(m_);
        Device* d = find(name);
        if (!d) return json_err("unknown_device");
        if (d->safety && estop_) return json_err("estop_active");
        std::string applied;
        for (const auto& pair : kv) {
            Prop* p = d->find(pair.first);
            if (!p) return json_err("unknown_property:" + pair.first);
            if (p->readonly) return json_err("read_only:" + pair.first);
            char* end = nullptr;
            const double req = std::strtod(pair.second.c_str(), &end);
            if (pair.second.empty() || *end != '\0' || std::isnan(req)) return json_err("bad_value:" + pair.first);
            if (d->kind == "lock" && pair.first == "locked" && req < 0.5 && !confirm) return json_err("confirmation_required");
        }
        for (const auto& pair : kv) {
            Prop* p = d->find(pair.first);
            const double req = std::strtod(pair.second.c_str(), nullptr);
            const double t = std::min(p->max, std::max(p->min, req));
            p->target = t;
            if (p->rate <= 0) p->value = t;
            applied += std::string(applied.empty() ? "" : ",") + json_str(pair.first) + ":{\"requested\":" + json_num(req) +
                       ",\"target\":" + json_num(t) + ",\"clamped\":" + (t != req ? "true" : "false") + "}";
        }
        return "{\"ok\":true,\"device\":" + json_str(name) + ",\"applied\":{" + applied + "},\"state\":" + dev_json(*d, false) + "}";
    }

    // Stop all safety-critical motion at once and refuse new motion until resume().
    std::string estop() {
        std::lock_guard<std::mutex> g(m_);
        estop_ = true;
        for (auto& d : devs_)
            if (d.safety) for (auto& kv : d.props) kv.second.target = kv.second.value;
        return "{\"ok\":true,\"estop\":true}";
    }
    std::string resume() {
        std::lock_guard<std::mutex> g(m_);
        estop_ = false;
        return "{\"ok\":true,\"estop\":false}";
    }

private:
    std::mutex m_;
    std::vector<Device> devs_;
    bool estop_ = false;

    static Prop mk(double v, double lo, double hi, double rate) { Prop p; p.value = p.target = v; p.min = lo; p.max = hi; p.rate = rate; return p; }
    static Prop ro(double v, double lo, double hi, double rate) { Prop p = mk(v, lo, hi, rate); p.readonly = true; return p; }
    void add(const std::string& n, const std::string& kind, bool safety, std::vector<std::pair<std::string, Prop>> props) {
        Device d; d.name = n; d.kind = kind; d.safety = safety; d.props = std::move(props); devs_.push_back(d);
    }
    Device* find(const std::string& n) { for (auto& d : devs_) if (d.name == n) return &d; return nullptr; }
    static std::string dev_json(const Device& d, bool keyed) {
        std::string o = keyed ? json_str(d.name) + ":" : "";
        o += "{\"kind\":" + json_str(d.kind) + ",\"props\":{";
        for (size_t i = 0; i < d.props.size(); i++) {
            const Prop& p = d.props[i].second;
            o += std::string(i ? "," : "") + json_str(d.props[i].first) + ":{\"value\":" + json_num(p.value) + ",\"target\":" + json_num(p.target) +
                 ",\"min\":" + json_num(p.min) + ",\"max\":" + json_num(p.max) + ",\"readonly\":" + (p.readonly ? "true" : "false") + "}";
        }
        return o + "}}";
    }
};

}  // namespace jrt
