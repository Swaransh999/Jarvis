// Real-time audio analysis (C++17, no dependencies): level, 8-band spectrum and speech detection.
// One call per audio frame (any length). Frames are 16-bit PCM, mono.
#pragma once
#include <algorithm>
#include <cmath>
#include <complex>
#include <cstdint>
#include <vector>

namespace jrt {

constexpr double kPi = 3.14159265358979323846;
using Complex = std::complex<double>;

// In-place iterative radix-2 FFT. The size must be a power of two.
inline void fft(std::vector<Complex>& a) {
    const size_t n = a.size();
    for (size_t i = 1, j = 0; i < n; i++) {
        size_t bit = n >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) std::swap(a[i], a[j]);
    }
    for (size_t len = 2; len <= n; len <<= 1) {
        const double ang = -2 * kPi / static_cast<double>(len);
        const Complex wl(std::cos(ang), std::sin(ang));
        for (size_t i = 0; i < n; i += len) {
            Complex w(1);
            for (size_t k = 0; k < len / 2; k++) {
                const Complex u = a[i + k], v = a[i + k + len / 2] * w;
                a[i + k] = u + v;
                a[i + k + len / 2] = u - v;
                w *= wl;
            }
        }
    }
}

struct Frame {
    double rms_db = -120, peak_db = -120, centroid_hz = 0;
    double bands[8] = {0, 0, 0, 0, 0, 0, 0, 0};  // 0..1, from -90 dBFS to 0 dBFS
    bool voiced = false;                          // this frame looks like speech
    bool speech = false;                          // currently inside a speech segment
    const char* event = "";                       // "speech_start", "speech_end" or ""
};

inline double to_db(double x) { return 20.0 * std::log10(std::max(x, 1e-6)); }

// Level, spectrum and centroid of one frame.
inline Frame analyze(const int16_t* s, size_t n, int rate) {
    Frame f;
    if (n == 0 || rate <= 0) return f;
    double sum2 = 0, peak = 0;
    for (size_t i = 0; i < n; i++) {
        const double x = s[i] / 32768.0;
        sum2 += x * x;
        peak = std::max(peak, std::fabs(x));
    }
    f.rms_db = to_db(std::sqrt(sum2 / static_cast<double>(n)));
    f.peak_db = to_db(peak);

    size_t N = 64;
    while (N * 2 <= n && N < 1024) N *= 2;
    std::vector<Complex> a(N);
    double sumw = 0;
    for (size_t i = 0; i < N; i++) {
        const double w = 0.5 - 0.5 * std::cos(2 * kPi * static_cast<double>(i) / static_cast<double>(N - 1));
        sumw += w;
        a[i] = Complex(i < n ? w * (s[i] / 32768.0) : 0.0, 0);
    }
    fft(a);

    const double nyq = rate / 2.0;
    const double edges[9] = {80, 160, 320, 640, 1280, 2560, 5120, 8000, 1e9};
    double amp_sum = 0, freq_amp = 0, band_peak[8] = {0, 0, 0, 0, 0, 0, 0, 0};
    for (size_t k = 1; k < N / 2; k++) {
        const double hz = static_cast<double>(k) * rate / static_cast<double>(N);
        if (hz > nyq) break;
        const double amp = 2.0 * std::abs(a[k]) / sumw;  // a full-scale sine reads 1.0
        amp_sum += amp;
        freq_amp += amp * hz;
        for (int b = 0; b < 8; b++)
            if (hz >= edges[b] && hz < edges[b + 1]) band_peak[b] = std::max(band_peak[b], amp);
    }
    f.centroid_hz = amp_sum > 1e-9 ? freq_amp / amp_sum : 0;
    for (int b = 0; b < 8; b++) f.bands[b] = std::min(1.0, std::max(0.0, (to_db(band_peak[b]) + 90.0) / 90.0));
    return f;
}

// Speech detector with an adaptive noise floor and hysteresis.
class Vad {
public:
    Frame process(const int16_t* s, size_t n, int rate) {
        Frame f = analyze(s, n, rate);
        if (n == 0 || rate <= 0) return f;
        const double ms = 1000.0 * static_cast<double>(n) / rate;
        const bool loud = f.rms_db > std::max(noise_ + 10.0, -48.0);
        const bool vocal = f.centroid_hz >= 120 && f.centroid_hz <= 3000;  // hiss and clicks sit higher
        f.voiced = loud && vocal;
        if (!f.voiced) noise_ = std::min(-35.0, std::max(-90.0, noise_ * 0.98 + f.rms_db * 0.02));
        if (f.voiced) { voiced_ms_ += ms; silence_ms_ = 0; } else { silence_ms_ += ms; voiced_ms_ = 0; }
        if (!speech_ && voiced_ms_ >= 60) { speech_ = true; f.event = "speech_start"; }
        else if (speech_ && silence_ms_ >= 300) { speech_ = false; f.event = "speech_end"; }
        f.speech = speech_;
        return f;
    }
private:
    double noise_ = -60, voiced_ms_ = 0, silence_ms_ = 0;
    bool speech_ = false;
};

}  // namespace jrt
