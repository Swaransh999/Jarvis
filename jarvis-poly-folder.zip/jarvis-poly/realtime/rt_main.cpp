// jarvis_rt: the real-time core of Jarvis (C++17).
//   * audio: speech detection, level and spectrum for streamed PCM frames (dsp.hpp)
//   * devices: IoT and robot hub with safety limits and an emergency stop (hub.hpp)
// The Python brain talks to it over a local TCP socket with a simple line protocol:
//   PING | STATE | GET <device> | SET <device> key=value ... [confirm=1] | ESTOP | RESUME
//   AUDIO <session> <sample_rate> <hex of 16-bit little-endian PCM> | AUDIOEND <session> | QUIT
// Every reply is one line of JSON. It listens on 127.0.0.1 only.
#include <arpa/inet.h>
#include <netinet/in.h>
#include <signal.h>
#include <sys/socket.h>
#include <unistd.h>

#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <map>
#include <mutex>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

#include "dsp.hpp"
#include "hub.hpp"

static jrt::Hub g_hub;
static std::map<std::string, jrt::Vad> g_vad;
static std::mutex g_vad_mutex;
static std::atomic<bool> g_run{true};

static std::vector<std::string> split(const std::string& s) {
    std::vector<std::string> out;
    std::istringstream is(s);
    for (std::string t; is >> t;) out.push_back(t);
    return out;
}

static bool decode_pcm(const std::string& hex, std::vector<int16_t>& out) {
    if (hex.size() % 4 != 0 || hex.size() > 400000) return false;
    auto nib = [](char c) -> int {
        if (c >= '0' && c <= '9') return c - '0';
        if (c >= 'a' && c <= 'f') return c - 'a' + 10;
        if (c >= 'A' && c <= 'F') return c - 'A' + 10;
        return -1;
    };
    out.resize(hex.size() / 4);
    for (size_t i = 0; i < out.size(); i++) {
        int b[4];
        for (int k = 0; k < 4; k++) if ((b[k] = nib(hex[i * 4 + k])) < 0) return false;
        out[i] = static_cast<int16_t>((b[0] << 4 | b[1]) | ((b[2] << 4 | b[3]) << 8));  // low byte first
    }
    return true;
}

std::string handle_line(const std::string& line) {
    const std::vector<std::string> t = split(line);
    if (t.empty()) return jrt::json_err("empty");
    const std::string& cmd = t[0];
    if (cmd == "PING") return "{\"ok\":true,\"pong\":true,\"service\":\"jarvis_rt\"}";
    if (cmd == "STATE") return g_hub.state_json();
    if (cmd == "GET" && t.size() == 2) return g_hub.get_json(t[1]);
    if (cmd == "ESTOP") return g_hub.estop();
    if (cmd == "RESUME") return g_hub.resume();
    if (cmd == "SET" && t.size() >= 3) {
        std::vector<std::pair<std::string, std::string>> kv;
        bool confirm = false;
        for (size_t i = 2; i < t.size(); i++) {
            const size_t eq = t[i].find('=');
            if (eq == std::string::npos || eq == 0) return jrt::json_err("bad_argument");
            const std::string k = t[i].substr(0, eq), v = t[i].substr(eq + 1);
            if (k == "confirm") confirm = (v == "1"); else kv.emplace_back(k, v);
        }
        return g_hub.set(t[1], kv, confirm);
    }
    if (cmd == "AUDIOEND" && t.size() == 2) {
        std::lock_guard<std::mutex> g(g_vad_mutex);
        g_vad.erase(t[1]);
        return "{\"ok\":true}";
    }
    if (cmd == "AUDIO" && t.size() == 4) {
        const int rate = std::atoi(t[2].c_str());
        std::vector<int16_t> pcm;
        if (rate < 8000 || rate > 48000 || !decode_pcm(t[3], pcm) || pcm.empty()) return jrt::json_err("bad_audio");
        jrt::Frame f;
        {
            std::lock_guard<std::mutex> g(g_vad_mutex);
            if (g_vad.size() > 256) g_vad.clear();
            f = g_vad[t[1]].process(pcm.data(), pcm.size(), rate);
        }
        std::string o = "{\"ok\":true,\"rms_db\":" + jrt::json_num(f.rms_db) + ",\"peak_db\":" + jrt::json_num(f.peak_db) +
                        ",\"centroid_hz\":" + jrt::json_num(f.centroid_hz) + ",\"bands\":[";
        for (int b = 0; b < 8; b++) o += (b ? "," : "") + jrt::json_num(f.bands[b]);
        return o + "],\"voiced\":" + (f.voiced ? "true" : "false") + ",\"speech\":" + (f.speech ? "true" : "false") +
               ",\"event\":\"" + f.event + "\"}";
    }
    return jrt::json_err("unknown_command");
}

static void send_all(int fd, const std::string& s) {
    size_t off = 0;
    while (off < s.size()) {
        const ssize_t n = send(fd, s.data() + off, s.size() - off, MSG_NOSIGNAL);
        if (n <= 0) return;
        off += static_cast<size_t>(n);
    }
}

static void serve_client(int fd) {
    std::string buf;
    char chunk[8192];
    for (;;) {
        const ssize_t n = recv(fd, chunk, sizeof chunk, 0);
        if (n <= 0) break;
        buf.append(chunk, static_cast<size_t>(n));
        if (buf.size() > 1000000) break;  // refuse absurd lines
        size_t nl;
        while ((nl = buf.find('\n')) != std::string::npos) {
            std::string line = buf.substr(0, nl);
            buf.erase(0, nl + 1);
            if (!line.empty() && line.back() == '\r') line.pop_back();
            if (line == "QUIT") { close(fd); return; }
            send_all(fd, handle_line(line) + "\n");
        }
    }
    close(fd);
}

static int selftest() {
    int failed = 0;
    auto check = [&](bool ok, const char* what) { std::printf("%s %s\n", ok ? "PASS" : "FAIL", what); if (!ok) failed++; };
    auto has = [](const std::string& s, const char* sub) { return s.find(sub) != std::string::npos; };
    auto hex_tone = [](double hz, double amp, int n, int rate) {
        std::string h;
        char b[8];
        for (int i = 0; i < n; i++) {
            const int16_t v = static_cast<int16_t>(amp * 32767.0 * std::sin(2 * jrt::kPi * hz * i / rate));
            std::snprintf(b, sizeof b, "%02x%02x", static_cast<unsigned>(v) & 0xff, (static_cast<unsigned>(v) >> 8) & 0xff);
            h += b;
        }
        return h;
    };
    const int rate = 16000;
    // spectrum: a 1 kHz tone at half scale must land in band 3 (640-1280 Hz) at about -9 dB
    std::string r = handle_line("AUDIO t1 16000 " + hex_tone(1000, 0.5, 512, rate));
    const size_t bp = r.find("\"bands\":[");
    double bands[8] = {0};
    if (bp != std::string::npos) std::sscanf(r.c_str() + bp + 9, "%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf", &bands[0], &bands[1], &bands[2], &bands[3], &bands[4], &bands[5], &bands[6], &bands[7]);
    check(bands[3] > 0.88 && bands[3] > bands[1] && bands[3] > bands[6], "FFT puts a 1 kHz tone in the 640-1280 Hz band");
    check(has(r, "\"rms_db\":-9.0") || has(r, "\"rms_db\":-9.1"), "RMS level of a half-scale sine is about -9 dB");
    // speech detection: silence -> voice -> silence
    handle_line("AUDIOEND v1");
    int starts = 0, ends = 0, start_frame = -1, end_frame = -1;
    const std::string quiet = hex_tone(440, 0.0, 320, rate), voice = hex_tone(440, 0.3, 320, rate);
    for (int i = 0; i < 60; i++) {
        const std::string& frame = (i >= 20 && i < 40) ? voice : quiet;
        const std::string o = handle_line("AUDIO v1 16000 " + frame);
        if (has(o, "speech_start")) { starts++; start_frame = i; }
        if (has(o, "speech_end")) { ends++; end_frame = i; }
    }
    check(starts == 1 && start_frame == 22, "speech_start fires after 60 ms of voice");
    check(ends == 1 && end_frame >= 54 && end_frame <= 56, "speech_end fires after 300 ms of silence");
    // hiss must not count as speech
    handle_line("AUDIOEND n1");
    unsigned seed = 12345;
    std::string noise;
    char b[8];
    for (int i = 0; i < 320; i++) {
        seed = seed * 1103515245u + 12345u;
        const int16_t v = static_cast<int16_t>((static_cast<int>((seed >> 16) & 0x7fff) - 16384) * 0.6);
        std::snprintf(b, sizeof b, "%02x%02x", static_cast<unsigned>(v) & 0xff, (static_cast<unsigned>(v) >> 8) & 0xff);
        noise += b;
    }
    int noise_starts = 0;
    for (int i = 0; i < 30; i++) if (has(handle_line("AUDIO n1 16000 " + noise), "speech_start")) noise_starts++;
    check(noise_starts == 0, "broadband hiss is not mistaken for speech");
    check(has(handle_line("AUDIO x 16000 zz"), "bad_audio"), "garbage audio is rejected");
    // devices and safety
    check(has(handle_line("SET light_living level=150 on=1"), "\"clamped\":true"), "light level 150 is clamped to 100");
    check(has(handle_line("SET thermostat setpoint=40"), "\"target\":30.00"), "thermostat setpoint is clamped to 30");
    check(has(handle_line("SET thermostat current=5"), "read_only"), "read-only properties are refused");
    check(has(handle_line("SET door_lock locked=0"), "confirmation_required"), "unlocking the door needs confirmation");
    check(has(handle_line("SET door_lock locked=0 confirm=1"), "\"ok\":true"), "unlocking works once confirmed");
    check(has(handle_line("SET nothing on=1"), "unknown_device"), "unknown device is refused");
    check(has(handle_line("SET light_living level=abc"), "bad_value"), "non-numeric value is refused");
    handle_line("SET robot_arm j1=120");
    g_hub.tick(0.5);
    check(has(handle_line("GET robot_arm"), "\"j1\":{\"value\":30.00,\"target\":90.00"), "arm moves at its speed limit (60 deg/s), not instantly");
    check(has(handle_line("ESTOP"), "\"estop\":true"), "emergency stop engages");
    g_hub.tick(0.5);
    check(has(handle_line("GET robot_arm"), "\"j1\":{\"value\":30.00,\"target\":30.00"), "emergency stop freezes the arm where it is");
    check(has(handle_line("SET robot_arm j1=0"), "estop_active"), "robot commands are refused during emergency stop");
    check(has(handle_line("SET light_living on=0"), "\"ok\":true"), "lights still work during a robot emergency stop");
    handle_line("RESUME");
    check(has(handle_line("SET robot_arm j1=0"), "\"ok\":true"), "robot accepts commands after resume");
    std::printf("%s\n", failed ? "SELF-TEST FAILED" : "SELF-TEST OK");
    return failed ? 1 : 0;
}

int main(int argc, char** argv) {
    int port = 7878;
    for (int i = 1; i < argc; i++) {
        if (!std::strcmp(argv[i], "--selftest")) return selftest();
        if (!std::strcmp(argv[i], "--port") && i + 1 < argc) port = std::atoi(argv[++i]);
    }
    signal(SIGPIPE, SIG_IGN);
    const int srv = socket(AF_INET, SOCK_STREAM, 0);
    int yes = 1;
    setsockopt(srv, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof yes);
    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(static_cast<uint16_t>(port));
    inet_pton(AF_INET, "127.0.0.1", &addr.sin_addr);
    if (bind(srv, reinterpret_cast<sockaddr*>(&addr), sizeof addr) != 0 || listen(srv, 16) != 0) {
        std::perror("jarvis_rt: cannot listen");
        return 1;
    }
    // real-time loop: 50 updates per second
    std::thread([] {
        auto next = std::chrono::steady_clock::now();
        while (g_run) {
            next += std::chrono::milliseconds(20);
            g_hub.tick(0.02);
            std::this_thread::sleep_until(next);
        }
    }).detach();
    std::printf("jarvis_rt listening on 127.0.0.1:%d\n", port);
    std::fflush(stdout);
    while (g_run) {
        const int c = accept(srv, nullptr, nullptr);
        if (c < 0) continue;
        std::thread(serve_client, c).detach();
    }
    return 0;
}
