"""Client for the C++ real-time core (jarvis_rt) over a local TCP socket."""
import json
import os
import socket
import subprocess
import threading
import time
from pathlib import Path


class RTError(Exception):
    pass


class RT:
    def __init__(self, host="127.0.0.1", port=7878):
        self.host, self.port = host, port
        self.sock = None
        self.buf = b""
        self.lock = threading.Lock()
        self.proc = None

    def _connect(self):
        s = socket.create_connection((self.host, self.port), timeout=2)
        s.settimeout(3)
        self.sock, self.buf = s, b""

    def call(self, line):
        """Send one command line, return the parsed JSON reply."""
        with self.lock:
            for attempt in (0, 1):
                try:
                    if not self.sock:
                        self._connect()
                    self.sock.sendall(line.encode() + b"\n")
                    while b"\n" not in self.buf:
                        chunk = self.sock.recv(65536)
                        if not chunk:
                            raise OSError("closed")
                        self.buf += chunk
                    reply, self.buf = self.buf.split(b"\n", 1)
                    return json.loads(reply)
                except (OSError, ValueError):
                    self.sock = None
                    if attempt:
                        raise RTError("The real-time core (jarvis_rt) is not running.")

    def alive(self):
        try:
            return bool(self.call("PING").get("pong"))
        except RTError:
            return False

    def state(self):
        return self.call("STATE")

    def set(self, device, props, confirm=False):
        args = " ".join(f"{k}={v}" for k, v in props.items())
        return self.call(f"SET {device} {args}" + (" confirm=1" if confirm else ""))

    def estop(self):
        return self.call("ESTOP")

    def resume(self):
        return self.call("RESUME")

    def audio(self, session, rate, pcm16le: bytes):
        return self.call(f"AUDIO {session} {int(rate)} {pcm16le.hex()}")

    def audio_end(self, session):
        return self.call(f"AUDIOEND {session}")

    def start(self, binary):
        """Start the daemon if it is not already listening. Returns True when it is up."""
        if self.alive():
            return True
        binary = Path(binary)
        if not binary.exists():
            return False
        self.proc = subprocess.Popen([str(binary), "--port", str(self.port)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(40):
            time.sleep(0.05)
            if self.alive():
                return True
        return False

    def stop(self):
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
