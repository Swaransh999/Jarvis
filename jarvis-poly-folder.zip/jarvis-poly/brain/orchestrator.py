"""Brain orchestration: gathers memory and device context, runs device actions, builds the LLM prompt extras."""
import re

from . import nlp
from .rt_client import RTError


def last_user_text(contents):
    """Text of the newest user message in a Gemini 'contents' list."""
    for item in reversed(contents or []):
        if isinstance(item, dict) and item.get("role") == "user":
            return " ".join(p.get("text", "") for p in item.get("parts", []) if isinstance(p, dict) and p.get("text"))
    return ""


class Orchestrator:
    def __init__(self, memory, rt):
        self.mem, self.rt = memory, rt

    def prepare(self, user, name, text, is_owner):
        """Before the LLM answers: run device commands (owner only), fetch relevant memories, learn new facts."""
        self.mem.ensure_user(user, name)
        notes, actions = [], []
        if is_owner:
            for intent in nlp.parse_device_intents(text):
                actions.append(self._act(user, intent))
        recalled = [r for r in self.mem.search(user, text, k=4) if r["kind"] != "message" or len(r["text"]) < 300]
        learned = nlp.extract_facts(text)
        for kind, sentence in learned:
            self.mem.remember(user, sentence, kind, 0.8)
        if len(text.split()) >= 4 and not learned:
            self.mem.remember(user, text, "message", 0.3)
        if recalled:
            notes.append("What you remember about this user (use it only when relevant, never recite it unprompted):\n" + "\n".join("- " + r["text"] for r in recalled))
        if actions:
            notes.append("Device actions Jarvis just carried out for the user (tell them the outcome in one short sentence, mention any refusal and why):\n" + "\n".join("- " + a for a in actions))
        return {"system": "\n\n".join(notes), "actions": actions, "learned": learned, "recalled": recalled}

    def _act(self, user, intent):
        try:
            if intent["action"] == "estop":
                r, label = self.rt.estop(), "emergency stop"
            elif intent["action"] == "resume":
                r, label = self.rt.resume(), "resume robot"
            else:
                label = f"{intent['device']} {intent['props']}"
                r = self.rt.set(intent["device"], intent["props"], intent.get("confirm", False))
        except RTError as e:
            self.mem.log_device(user, intent.get("device", "-"), str(intent), False, str(e))
            return f"{intent.get('device', 'robot')}: failed, the real-time core is offline"
        ok = bool(r.get("ok"))
        if ok and intent["action"] == "set":
            clamped = [k for k, v in r.get("applied", {}).items() if v.get("clamped")]
            summary = f"{label}: done" + (f" (limited to the safe range for {', '.join(clamped)})" if clamped else "")
        elif ok:
            summary = f"{label}: done"
        else:
            err = r.get("error", "refused")
            summary = f"{label}: refused ({err})" + (". The user must say 'confirm' to unlock the door." if err == "confirmation_required" else "")
        self.mem.log_device(user, intent.get("device", "robot"), str(intent), ok, summary)
        return summary

    def finish(self, user, user_text, answer):
        """After the LLM answered: store the exchange."""
        if user_text:
            self.mem.add_message(user, "user", user_text)
        if answer.strip():
            self.mem.add_message(user, "assistant", answer)
