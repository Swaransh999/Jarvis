#!/usr/bin/env python3
"""
Jarvis brain server (Python / Flask).

Run:   python run.py          then open http://localhost:5000

It serves the website in public/ and the API under /api/. All keys come from keys.env
(plain NAME=value lines). Environment variables with the same names override keys.env.
Every value is cleaned automatically: spaces, line breaks and quote marks are removed.
"""
import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import sys
import time
from pathlib import Path

import requests
from werkzeug.exceptions import HTTPException
from flask import Flask, Response, jsonify, request, send_from_directory, stream_with_context

from .memory import Memory
from .orchestrator import Orchestrator, last_user_text
from .rt_client import RT, RTError

HERE = Path(__file__).resolve().parent.parent   # project folder (keys.env, public/, sql/, realtime/)
G = "https://generativelanguage.googleapis.com/v1beta"
EL = "https://api.elevenlabs.io/v1"
STRIPE = "https://api.stripe.com/v1"
IXD = "id.jarvis-users.example"

NAMES = [
    "GEMINI_API_KEY", "ELEVENLABS_API_KEY", "JWT_SECRET", "STRIPE_SECRET_KEY",
    "GOOGLE_CLIENT_ID", "META_APP_ID", "ADOBE_CLIENT_ID",
    "ELEVENLABS_VOICE_ID", "ELEVENLABS_MODEL",
    "GEMINI_MODEL_QUICK", "GEMINI_MODEL_FAST", "GEMINI_MODEL_THINK", "GEMINI_MODEL_BUILD",
    "GEMINI_MODEL_IMAGE", "GEMINI_MODEL_VIDEO",
    "OWNER_ID", "OWNER_SALT", "OWNER_HASH",
]

SYS = ("You are Jarvis, a professional, highly capable AI assistant. You answer anything, write any code and build "
       "anything the user asks for, generating everything live with no canned responses. Reply in the user's language "
       "and keep prose clear and concise. Put code in properly labelled fences.")
MODES = {
    "quick": {"sys": "Answer in one to three sentences. Be direct."},
    "fast": {"sys": ""},
    "think": {"pro": True, "sys": "Reason step by step before answering, double-check your work, then give a thorough, well-structured answer."},
    "media": {"pro": True, "sys": ""},
    "build": {"pro": True, "sys": "You are in Build mode. Reply with one complete, polished, self-contained HTML file (inline CSS and JS, no external dependencies) in a single ```html block so it runs in the live preview, then add a two-line usage note."},
}
PRO_MSG = "Deep thinking, Image and Video Generation and Build are part of Jarvis Pro."
RETRY = (400, 403, 404, 429, 503)


def clean(value):
    """Remove all whitespace, then any quote marks around the value."""
    return re.sub(r"\s+", "", str(value if value is not None else "")).strip("\"'`")


# ---------- settings: keys.env first, then environment variables ----------
E, SRC = {n: "" for n in NAMES}, {}
env_file = HERE / "keys.env"
if env_file.exists():
    for line in env_file.read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            k = k.strip()
            if k in E:
                E[k], SRC[k] = clean(v), "keys.env"
for k in NAMES:
    if clean(os.environ.get(k, "")):
        E[k], SRC[k] = clean(os.environ[k]), "environment variable"


def hint(k):
    return f"ending ...{E[k][-4:]}, {len(E[k])} characters, from {SRC.get(k, 'keys.env')}" if E[k] else "none"


class ApiError(Exception):
    def __init__(self, message, status=500):
        super().__init__(message)
        self.status = status


app = Flask(__name__, static_folder=None)

# ---------- the other layers: SQL memory, C++ real-time core, orchestration ----------
MEM = Memory(os.environ.get("JARVIS_DB") or HERE / "data" / "jarvis_memory.db", HERE / "sql")
RTC = RT(port=int(os.environ.get("RT_PORT", "7878")))
ORCH = Orchestrator(MEM, RTC)
SAFE = re.compile(r"^[A-Za-z0-9_.\-]{1,40}$")


def out(obj, status=200):
    r = jsonify(obj)
    r.status_code = status
    r.headers["Cache-Control"] = "no-store"
    return r


def fail(message, status=400):
    return out({"error": message}, status)


@app.errorhandler(ApiError)
def on_api_error(e):
    return fail(str(e), e.status)


@app.errorhandler(Exception)
def on_error(e):
    if isinstance(e, HTTPException):          # 404 for missing files, 405, etc. keep their own status
        return fail(e.description, e.code)
    return fail(str(e) or "Server error.", 500)


@app.after_request
def headers(r):
    r.headers["Permissions-Policy"] = "microphone=(self), camera=(self), geolocation=(self)"
    r.headers["X-Content-Type-Options"] = "nosniff"
    r.headers["X-Robots-Tag"] = "noindex, nofollow"
    return r


# ---------- passwords and login tokens ----------
def hash_pw(password, salt):
    return hashlib.scrypt(password.encode(), salt=salt.encode(), n=16384, r=8, p=1, dklen=64).hex()


def same(a, b):
    return hmac.compare_digest(str(a).encode(), str(b).encode())


def b64u(data):
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def mac(text):
    return b64u(hmac.new(E["JWT_SECRET"].encode(), text.encode(), hashlib.sha256).digest())


def sign(payload):
    head = b64u(b'{"alg":"HS256","typ":"JWT"}')
    body = b64u(json.dumps({**payload, "exp": int(time.time()) + 30 * 86400}).encode())
    return f"{head}.{body}.{mac(head + '.' + body)}"


def verify(token):
    try:
        head, body, sig = token.split(".")
        if not same(sig, mac(head + "." + body)):
            return None
        data = json.loads(base64.urlsafe_b64decode(body + "=" * (-len(body) % 4)))
        return data if data["exp"] > time.time() else None
    except Exception:
        return None


# ---------- Stripe is the account and subscription store ----------
def stripe(path, method="GET", params=None):
    if not E["STRIPE_SECRET_KEY"]:
        raise ApiError("Accounts aren't set up yet (STRIPE_SECRET_KEY is empty in keys.env).", 500)
    r = requests.request(method, STRIPE + path, headers={"Authorization": "Bearer " + E["STRIPE_SECRET_KEY"]},
                         params=params if method == "GET" else None, data=params if method == "POST" else None, timeout=30)
    j = r.json()
    if not r.ok:
        raise ApiError((j.get("error") or {}).get("message", "Billing error"), 500)
    return j


def by_email(email):
    data = stripe("/customers", params={"email": email, "limit": 5})["data"]
    return data[0] if data else None


sub_cache = {}


def plan(u):
    if u.get("own"):
        return {"plan": "owner"}
    hit = sub_cache.get(u["sub"])
    if hit and time.time() - hit[0] < 60:
        return hit[1]
    subs = stripe("/subscriptions", params={"customer": u["sub"], "status": "all", "limit": 10})["data"]
    s = next((x for x in subs if x["status"] in ("active", "trialing")), None)
    if s:
        item = ((s.get("items") or {}).get("data") or [{}])[0]
        v = {"plan": "pro", "interval": ((item.get("price") or {}).get("recurring") or {}).get("interval", ""),
             "end": item.get("current_period_end") or s.get("current_period_end") or 0}
    else:
        v = {"plan": "free"}
    sub_cache[u["sub"]] = (time.time(), v)
    return v


def is_pro(u):
    return plan(u)["plan"] != "free"


# ---------- always use the newest models the keys can reach ----------
MC = {"t": 0}


def ver(n):
    m = re.search(r"(\d+(?:\.\d+)?)", n)
    return float(m.group(1)) if m else 0.0


def rank(names, test):
    return sorted([n for n in names if test(n)], key=lambda n: (-ver(n), 1 if re.search("preview|exp", n) else 0, len(n)))


def models():
    if time.time() - MC["t"] < 3600 and len(MC) > 1:
        return MC
    allm = []
    try:
        r = requests.get(G + "/models?pageSize=200", headers={"x-goog-api-key": E["GEMINI_API_KEY"]}, timeout=20)
        if r.ok:
            allm = r.json().get("models", [])
    except Exception:
        pass

    def has(m, method):
        return method in m.get("supportedGenerationMethods", [])

    def nm(m):
        return m["name"][7:]

    txt = [nm(m) for m in allm if has(m, "generateContent") and re.match(r"models/gemini-\d", m["name"])
           and not re.search("tts|image|live|audio|embedding|robotics|computer|custom", m["name"])]
    vv = [nm(m) for m in allm if has(m, "predictLongRunning") and "veo" in m["name"]]
    M = {"t": time.time(),
         "quick": rank(txt, lambda n: "flash-lite" in n),
         "fast": rank(txt, lambda n: "flash" in n and "lite" not in n),
         "think": rank(txt, lambda n: "pro" in n),
         "image": rank([nm(m) for m in allm if has(m, "generateContent") and re.match(r"models/gemini-.*image", m["name"])], lambda n: True),
         "video": rank(vv, lambda n: "fast" not in n) + rank(vv, lambda n: "fast" in n)}
    M["build"] = M["think"]
    fallback = {"quick": "gemini-flash-lite-latest", "fast": "gemini-flash-latest", "think": "gemini-pro-latest",
                "build": "gemini-pro-latest", "image": "gemini-2.5-flash-image", "video": "veo-3.0-generate-001"}
    for k, fb in fallback.items():
        named = E["GEMINI_MODEL_" + k.upper()].removeprefix("models/")
        merged = ([named] if named else []) + M[k] + [fb]
        M[k] = [x for i, x in enumerate(merged) if x not in merged[:i]]
    MC.clear()
    MC.update(M)
    return MC


def gem(models_list, path, body, stream=False):
    if not E["GEMINI_API_KEY"]:
        raise ApiError("Gemini isn't set up (GEMINI_API_KEY is empty in keys.env).", 500)
    last = None
    for m in models_list[:3]:
        r = requests.post(f"{G}/models/{m}{path}", headers={"x-goog-api-key": E["GEMINI_API_KEY"]}, json=body, stream=stream, timeout=300)
        if r.ok:
            return r
        last = r
        if r.status_code not in RETRY:
            break
    raise ApiError(f"Gemini error {last.status_code}: {last.text[:200]}", 502)


EL_MODEL = {"id": ""}


def el_model():
    if EL_MODEL["id"]:
        return EL_MODEL["id"]
    EL_MODEL["id"] = E["ELEVENLABS_MODEL"] or "eleven_multilingual_v2"
    if not E["ELEVENLABS_MODEL"]:
        try:
            r = requests.get(EL + "/models", headers={"xi-api-key": E["ELEVENLABS_API_KEY"]}, timeout=15)
            if r.ok:
                ids = [m["model_id"] for m in r.json() if m.get("can_do_text_to_speech")]
                EL_MODEL["id"] = next((x for x in ("eleven_v3", "eleven_multilingual_v2", "eleven_turbo_v2_5", "eleven_flash_v2_5") if x in ids), EL_MODEL["id"])
        except Exception:
            pass
    return EL_MODEL["id"]


deep_cache = {"t": 0, "v": None}


def probe(name, url, headers):
    try:
        r = requests.get(url, headers=headers, timeout=15)
        if r.ok:
            return {"ok": 1}
        try:
            j = r.json()
            d = j.get("error") or j.get("detail") or j
            msg = d if isinstance(d, str) else (d.get("message") or d.get("status") or json.dumps(d))
        except Exception:
            msg = ""
        return {"ok": 0, "status": r.status_code, "message": str(msg)[:160]}
    except Exception:
        return {"ok": 0, "status": 0, "message": "Could not reach " + name}


# ---------- website ----------
@app.route("/")
def home():
    return send_from_directory(HERE / "public", "index.html")


@app.route("/<path:name>")
def files(name):
    return send_from_directory(HERE / "public", name)


# ---------- API ----------
@app.route("/api/<path:p>", methods=["GET", "POST"])
def api(p):
    p = "/" + p
    if p == "/health":
        base = {"ok": 1, "jwt": bool(E["JWT_SECRET"]), "stripe": bool(E["STRIPE_SECRET_KEY"]),
                "gemini": bool(E["GEMINI_API_KEY"]), "eleven": bool(E["ELEVENLABS_API_KEY"]),
                "hints": {"gemini": hint("GEMINI_API_KEY"), "eleven": hint("ELEVENLABS_API_KEY"), "stripe": hint("STRIPE_SECRET_KEY")}}
        if request.args.get("deep"):
            if time.time() - deep_cache["t"] > 30:
                deep_cache["v"] = {
                    "gemini": probe("Gemini", G + "/models?pageSize=1", {"x-goog-api-key": E["GEMINI_API_KEY"]}) if E["GEMINI_API_KEY"] else {"ok": 0, "message": "No key set in keys.env"},
                    "eleven": probe("ElevenLabs", EL + "/models", {"xi-api-key": E["ELEVENLABS_API_KEY"]}) if E["ELEVENLABS_API_KEY"] else {"ok": 0, "message": "No key set in keys.env"},
                    "stripe": probe("Stripe", STRIPE + "/customers?limit=1", {"Authorization": "Bearer " + E["STRIPE_SECRET_KEY"]}) if E["STRIPE_SECRET_KEY"] else {"ok": 0, "message": "No key set in keys.env"}}
                deep_cache["t"] = time.time()
            base["checks"] = deep_cache["v"]
            M = models()
            base["using"] = {k: M[k][0] for k in ("quick", "fast", "think", "build", "image", "video")}
            base["using"].update({"voice": E["ELEVENLABS_VOICE_ID"] or "JBFqnCBsd6RMkjVDRZzb", "voiceModel": el_model()})
        return out(base)
    if p == "/config":
        return out({"google": E["GOOGLE_CLIENT_ID"], "meta": E["META_APP_ID"], "adobe": E["ADOBE_CLIENT_ID"]})
    if not E["JWT_SECRET"]:
        return fail("The server isn't configured yet (JWT_SECRET is empty in keys.env).", 500)
    b = (request.get_json(silent=True) or {}) if request.method == "POST" else {}

    if p == "/signup":
        uid, email, pw = str(b.get("id", "")).strip(), str(b.get("email", "")).strip().lower(), str(b.get("password", ""))
        if not re.fullmatch(r"[A-Za-z0-9_]{3,24}", uid):
            return fail("Your Jarvis ID must be 3 to 24 letters, numbers or underscores.")
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
            return fail("Enter a valid email address.")
        if len(pw) < 8:
            return fail("Your password must be at least 8 characters.")
        if uid.lower() == E["OWNER_ID"].lower():
            return fail("That ID is reserved.", 409)
        if by_email(email):
            return fail("An account with that email already exists. Log in instead.", 409)
        if by_email(f"{uid.lower()}@{IXD}"):
            return fail("That Jarvis ID is taken.", 409)
        salt = secrets.token_hex(16)
        c = stripe("/customers", "POST", {"email": email, "name": uid, "metadata[jid]": uid.lower(), "metadata[pw]": hash_pw(pw, salt),
                                         "metadata[salt]": salt, "metadata[prov]": "jarvis"})
        stripe("/customers", "POST", {"email": f"{uid.lower()}@{IXD}", "name": "ID " + uid, "metadata[ref]": c["id"]})
        return out({"token": sign({"sub": c["id"], "name": uid}), "user": {"name": uid, "plan": "free"}})

    if p == "/login":
        uid, pw = str(b.get("id", "")).strip(), str(b.get("password", ""))
        if uid.lower() == E["OWNER_ID"].lower():
            if not same(hash_pw(pw, E["OWNER_SALT"]), E["OWNER_HASH"]):
                time.sleep(0.9)
                return fail("Wrong ID or password.", 401)
            return out({"token": sign({"sub": "owner", "name": E["OWNER_ID"], "own": 1}), "user": {"name": E["OWNER_ID"], "plan": "owner"}})
        c = None
        if "@" in uid:
            c = by_email(uid.lower())
        else:
            ix = by_email(f"{uid.lower()}@{IXD}")
            if ix and (ix.get("metadata") or {}).get("ref"):
                c = stripe("/customers/" + ix["metadata"]["ref"])
        md = (c or {}).get("metadata") or {}
        if not c or c.get("deleted") or not md.get("pw") or not same(hash_pw(pw, md.get("salt", "")), md["pw"]):
            time.sleep(0.9)
            return fail("Wrong ID or password.", 401)
        t = {"sub": c["id"], "name": c["name"]}
        return out({"token": sign(t), "user": {"name": c["name"], **plan(t)}})

    if p == "/oauth":
        prov, tok = b.get("provider"), str(b.get("token", ""))
        if prov == "google":
            if not E["GOOGLE_CLIENT_ID"]:
                return fail("Google sign-in isn't set up yet.", 501)
            ti = requests.get(f"https://oauth2.googleapis.com/tokeninfo?access_token={tok}", timeout=15).json()
            if ti.get("aud") != E["GOOGLE_CLIENT_ID"]:
                return fail("Google sign-in failed.", 401)
            ui = requests.get("https://www.googleapis.com/oauth2/v3/userinfo", headers={"Authorization": "Bearer " + tok}, timeout=15).json()
            if not ui.get("email") or ui.get("email_verified") is False:
                return fail("Your Google email isn't verified.", 401)
            email, name = ui["email"], ui.get("name")
        elif prov == "meta":
            if not E["META_APP_ID"]:
                return fail("Meta sign-in isn't set up yet.", 501)
            app_info = requests.get("https://graph.facebook.com/app", params={"access_token": tok}, timeout=15).json()
            if str(app_info.get("id")) != E["META_APP_ID"]:
                return fail("Meta sign-in failed.", 401)
            me = requests.get("https://graph.facebook.com/me", params={"fields": "name,email", "access_token": tok}, timeout=15).json()
            if not me.get("email"):
                return fail("Your Meta account didn't share an email address.", 401)
            email, name = me["email"], me.get("name")
        elif prov == "adobe":
            if not E["ADOBE_CLIENT_ID"]:
                return fail("Adobe sign-in isn't set up yet.", 501)
            v = requests.get("https://ims-na1.adobelogin.com/ims/validate_token/v1", params={"type": "access_token", "client_id": E["ADOBE_CLIENT_ID"]},
                             headers={"Authorization": "Bearer " + tok}, timeout=15).json()
            if not v.get("valid"):
                return fail("Adobe sign-in failed.", 401)
            ui = requests.get("https://ims-na1.adobelogin.com/ims/userinfo/v2", headers={"Authorization": "Bearer " + tok}, timeout=15).json()
            if not ui.get("email"):
                return fail("Your Adobe account didn't share an email address.", 401)
            email, name = ui["email"], ui.get("name") or ui.get("display_name")
        else:
            return fail("That sign-in isn't available.", 501)
        email = email.lower()
        c = by_email(email)
        if c and (c.get("metadata") or {}).get("pw"):
            return fail("That email already has a Jarvis account. Log in with your Jarvis ID and password.", 409)
        if not c:
            c = stripe("/customers", "POST", {"email": email, "name": name or email, "metadata[prov]": prov})
        tk = {"sub": c["id"], "name": name or c.get("name") or email}
        return out({"token": sign(tk), "user": {"name": tk["name"], **plan(tk)}})

    u = verify(request.headers.get("Authorization", "")[7:])
    if not u:
        return fail("Please log in.", 401)

    if p == "/me":
        if request.args.get("fresh"):
            sub_cache.pop(u["sub"], None)
        return out({"name": u["name"], **plan(u)})

    if p == "/checkout":
        if u.get("own"):
            return fail("The owner account already has everything unlocked.")
        if is_pro(u):
            return fail("You already have Jarvis Pro.")
        year = b.get("interval") == "year"
        pre = "line_items[0][price_data]"
        origin = request.host_url.rstrip("/")
        s = stripe("/checkout/sessions", "POST", {
            "mode": "subscription", "customer": u["sub"], "line_items[0][quantity]": 1, pre + "[currency]": "usd",
            pre + "[unit_amount]": 96000 if year else 8000, pre + "[recurring][interval]": "year" if year else "month",
            pre + "[product_data][name]": "Jarvis Pro (" + ("yearly" if year else "monthly") + ")",
            "success_url": origin + "/?sub=success", "cancel_url": origin + "/?sub=cancel", "allow_promotion_codes": "true"})
        return out({"url": s["url"]})

    if p == "/portal":
        if u.get("own"):
            return fail("The owner account has no subscription to manage.")
        s = stripe("/billing_portal/sessions", "POST", {"customer": u["sub"], "return_url": request.host_url})
        return out({"url": s["url"]})

    if p == "/tts":
        if not E["ELEVENLABS_API_KEY"]:
            return fail("Voice isn't set up (ELEVENLABS_API_KEY is empty in keys.env).", 500)
        text = str(b.get("text", ""))[:1200]
        if not text:
            return fail("Nothing to say.")
        voice = E["ELEVENLABS_VOICE_ID"] or "JBFqnCBsd6RMkjVDRZzb"

        def speak(model):
            return requests.post(f"{EL}/text-to-speech/{voice}", params={"output_format": "mp3_44100_128"},
                                 headers={"xi-api-key": E["ELEVENLABS_API_KEY"]}, json={"text": text, "model_id": model}, timeout=120)
        r = speak(el_model())
        if not r.ok and EL_MODEL["id"] != "eleven_multilingual_v2":
            r = speak("eleven_multilingual_v2")
        if not r.ok:
            return fail(f"Voice unavailable right now ({r.status_code}).", 502)
        return Response(r.content, mimetype="audio/mpeg", headers={"Cache-Control": "no-store"})

    if p == "/chat":
        mode = b.get("mode")
        m = MODES.get(mode)
        if not m or not isinstance(b.get("contents"), list):
            return fail("Bad request.")
        if m.get("pro") and not is_pro(u):
            return fail(PRO_MSG, 402)
        text = last_user_text(b["contents"])
        ctx = ORCH.prepare(u["sub"], u.get("name", ""), text, bool(u.get("own")))       # SQL memory + C++ device actions
        loc = str(b.get("loc") or "")[:30]
        sys_text = (SYS + (f"\n\nThe user's approximate coordinates are {loc}. Mention or use them only when relevant." if loc else "")
                    + (("\n\n" + m["sys"]) if m["sys"] else "") + (("\n\n" + ctx["system"]) if ctx["system"] else ""))
        r = gem(models()[mode], ":streamGenerateContent?alt=sse", {"systemInstruction": {"parts": [{"text": sys_text}]}, "contents": b["contents"]}, stream=True)

        def gen():
            got = []
            try:
                for raw in r.iter_lines():
                    line = raw.decode("utf-8", "ignore")
                    if not line.startswith("data:"):
                        continue
                    try:
                        j = json.loads(line[5:])
                    except ValueError:
                        continue
                    for cd in j.get("candidates", []):
                        for pt in (cd.get("content") or {}).get("parts", []):
                            if pt.get("text") and not pt.get("thought"):
                                got.append(pt["text"])
                                yield pt["text"].encode("utf-8")
            finally:
                ORCH.finish(u["sub"], text, "".join(got))                                # store the exchange in SQL
        return Response(stream_with_context(gen()), mimetype="text/plain", headers={"Cache-Control": "no-store", "X-Accel-Buffering": "no"})

    if p in ("/image", "/video", "/videofile"):
        if not is_pro(u):
            return fail(PRO_MSG, 402)
        if p == "/image":
            photos = b.get("photos") if isinstance(b.get("photos"), list) else []
            parts = [{"inlineData": {"mimeType": x.get("mime"), "data": x.get("data")}} for x in photos[:4]] + [{"text": str(b.get("prompt", ""))[:2000]}]
            r = gem(models()["image"], ":generateContent", {"contents": [{"parts": parts}], "generationConfig": {"responseModalities": ["TEXT", "IMAGE"]}})
            cand = (r.json().get("candidates") or [{}])[0]
            ps = (cand.get("content") or {}).get("parts", [])
            im = next((x for x in ps if x.get("inlineData") or x.get("inline_data")), None)
            if not im:
                return fail(" ".join(x.get("text", "") for x in ps).strip() or "No image came back. Try rephrasing.", 422)
            d = im.get("inlineData") or im.get("inline_data")
            return out({"src": f"data:{d.get('mimeType') or d.get('mime_type') or 'image/png'};base64,{d['data']}",
                        "text": " ".join(x["text"] for x in ps if x.get("text"))})
        if p == "/video":
            if not E["GEMINI_API_KEY"]:
                return fail("Gemini isn't set up (GEMINI_API_KEY is empty in keys.env).", 500)
            if b.get("op"):
                if not re.fullmatch(r"models/[\w.\-]+/operations/[\w\-]+", str(b["op"])):
                    return fail("Bad operation.")
                j = requests.get(f"{G}/{b['op']}", headers={"x-goog-api-key": E["GEMINI_API_KEY"]}, timeout=30).json()
                if j.get("error"):
                    return out({"error": j["error"].get("message", "Video failed.")})
                if not j.get("done"):
                    return out({"done": False})
                samples = ((j.get("response") or {}).get("generateVideoResponse") or {}).get("generatedSamples") or [{}]
                uri = (samples[0].get("video") or {}).get("uri")
                return out({"done": True, "uri": uri} if uri else {"error": "The video was blocked or came back empty. Try a different prompt."})
            last = None
            for mdl in models()["video"][:3]:
                r = requests.post(f"{G}/models/{mdl}:predictLongRunning", headers={"x-goog-api-key": E["GEMINI_API_KEY"]},
                                  json={"instances": [{"prompt": str(b.get("prompt", ""))[:2000]}]}, timeout=60)
                if r.ok:
                    return out({"op": r.json()["name"]})
                last = r
                if r.status_code not in RETRY:
                    break
            return fail(f"Video error {last.status_code}: {last.text[:200]} (video generation needs a paid Gemini key).", 502)
        uri = request.args.get("uri", "")
        if not re.match(r"https://generativelanguage\.googleapis\.com/", uri):
            return fail("Bad link.")
        r = requests.get(uri, headers={"x-goog-api-key": E["GEMINI_API_KEY"]}, stream=True, timeout=120)
        if not r.ok:
            return fail("Could not fetch the video.", 502)
        return Response(r.iter_content(65536), content_type=r.headers.get("content-type", "video/mp4"), headers={"Cache-Control": "no-store"})

    # ---------- dashboard endpoints: memory (SQL), devices and audio (C++ real-time core) ----------
    if p == "/system":
        return out({"brain": {"ok": True, "python": sys.version.split()[0]}, "memory": MEM.stats(u["sub"]), "realtime": {"ok": RTC.alive()}, "owner": bool(u.get("own"))})

    if p == "/memory":
        MEM.ensure_user(u["sub"], u.get("name", ""))
        if request.method == "POST":
            text = str(b.get("text", "")).strip()
            if not text:
                return fail("Write something to remember.")
            return out({"id": MEM.remember(u["sub"], text, "note", 0.9)})
        q = request.args.get("q", "").strip()
        return out({"memories": MEM.search(u["sub"], q, k=20) if q else MEM.list(u["sub"], 100)})
    if p == "/memory/delete":
        MEM.forget(u["sub"], int(b.get("id", 0)))
        return out({"ok": True})

    if p == "/audio":
        data = request.get_data()
        if not 64 <= len(data) <= 65536:
            return fail("Send 64 bytes to 64 KB of 16-bit PCM audio.")
        try:
            return out(RTC.audio(re.sub(r"\W", "", u["sub"])[:40] or "u", int(request.headers.get("X-Sample-Rate", 16000)), data))
        except (RTError, ValueError) as e:
            return fail(str(e), 503)

    if p.startswith("/devices"):
        if not u.get("own"):
            return fail("Device control is for the owner account.", 403)
        try:
            if p == "/devices":
                return out({**RTC.state(), "log": MEM.device_log(10)})
            if p == "/devices/estop":
                MEM.log_device(u["sub"], "robot", "emergency stop", True, "emergency stop")
                return out(RTC.estop())
            if p == "/devices/resume":
                return out(RTC.resume())
            if p == "/devices/set":
                dev, props = str(b.get("device", "")), b.get("props") or {}
                if not SAFE.match(dev) or not isinstance(props, dict) or not props or not all(SAFE.match(str(k)) and SAFE.match(str(v)) for k, v in props.items()):
                    return fail("Bad device command.")
                r = RTC.set(dev, props, bool(b.get("confirm")))
                MEM.log_device(u["sub"], dev, json.dumps(props), bool(r.get("ok")), "ok" if r.get("ok") else str(r.get("error")))
                return out(r)
        except RTError as e:
            return fail(str(e), 503)

    return fail("Not found.", 404)


def start_realtime():
    """Start the C++ real-time core if it is built. Chat and memory still work without it."""
    return RTC.start(os.environ.get("RT_BIN") or HERE / "realtime" / "jarvis_rt")


def main():
    port = int(os.environ.get("PORT", 5000))
    print(f"\nJarvis is running at http://localhost:{port}")
    print("  real-time core (C++):", "running" if start_realtime() else "NOT running (run: make -C realtime)")
    print("  memory (SQL):         ", HERE / "data" / "jarvis_memory.db")
    for label, k in (("Gemini", "GEMINI_API_KEY"), ("ElevenLabs", "ELEVENLABS_API_KEY"), ("Stripe", "STRIPE_SECRET_KEY")):
        print(f"  {label:11} key {hint(k)}")
    if not E["JWT_SECRET"]:
        print("  WARNING: JWT_SECRET is empty in keys.env, so nobody can log in.")
    try:
        app.run(host=os.environ.get("HOST", "127.0.0.1"), port=port, threaded=True)
    finally:
        RTC.stop()


if __name__ == "__main__":
    main()
