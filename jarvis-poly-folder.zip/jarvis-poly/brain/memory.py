"""Memory layer: runs the SQL in sql/ (SQLite). Python only prepares inputs and reads rows back.

Retrieval is hybrid and happens entirely inside one SQL query (see search_hybrid in sql/queries.sql):
a sparse vector index (cosine similarity), BM25 keyword search and a stored importance score.
Embeddings here are local feature-hashing vectors, so memory works offline and costs nothing.
"""
import json
import math
import re
import sqlite3
import threading
import zlib
from pathlib import Path

DIMS = 1024
STOP = set("a an and are as at be but by do for from has have i if in is it me my of on or so that the this to was we what when where which who will with you your am im ive can could would should please tell about".split())


def tokens(text):
    return [t for t in re.findall(r"\w+", text.lower(), re.UNICODE) if t not in STOP and len(t) > 1]


def embed(text):
    """Feature-hashed bag of words and word pairs, L2-normalised. Returns ([(dim, value), ...], norm)."""
    toks = tokens(text)
    feats = toks + [a + "_" + b for a, b in zip(toks, toks[1:])]
    acc = {}
    for f in feats:
        h = zlib.crc32(f.encode("utf-8"))
        dim, sign = h % DIMS, 1.0 if (h >> 20) & 1 else -1.0
        acc[dim] = acc.get(dim, 0.0) + sign
    norm = math.sqrt(sum(v * v for v in acc.values()))
    if norm == 0:
        return [], 0.0
    return [(d, v / norm) for d, v in acc.items()], 1.0


def fts_query(text):
    toks = list(dict.fromkeys(tokens(text)))[:12]
    return " OR ".join('"%s"' % t.replace('"', "") for t in toks) or '"__none__"'


class Memory:
    def __init__(self, db_path, sql_dir):
        sql_dir = Path(sql_dir)
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(str(db_path), check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        self.q = {}
        name = None
        for line in (sql_dir / "queries.sql").read_text(encoding="utf-8").splitlines():
            m = re.match(r"--\s*name:\s*(\w+)", line)
            if m:
                name = m.group(1)
                self.q[name] = []
            elif name and not line.strip().startswith("--"):
                self.q[name].append(line)
        self.q = {k: "\n".join(v).strip().rstrip(";") for k, v in self.q.items()}
        with self.lock:
            self.db.executescript((sql_dir / "schema.sql").read_text(encoding="utf-8"))

    def run(self, name, params=None, one=False, many=False):
        with self.lock:
            cur = self.db.execute(self.q[name], params or {})
            if many:
                rows = [dict(r) for r in cur.fetchall()]
            elif one:
                r = cur.fetchone()
                rows = dict(r) if r else None
            else:
                rows = cur.lastrowid
            self.db.commit()
            return rows

    # ---- users and conversations ----
    def ensure_user(self, user, name=""):
        self.run("upsert_user", {"user": user, "name": name})

    def conversation(self, user):
        row = self.run("latest_conversation", {"user": user}, one=True)
        return row["id"] if row else self.run("new_conversation", {"user": user, "title": "Conversation"})

    def add_message(self, user, role, content):
        conv = self.conversation(user)
        self.run("insert_message", {"conv": conv, "user": user, "role": role, "content": content[:20000]})
        self.run("touch_conversation", {"id": conv})

    def recent(self, user, n=10):
        conv = self.conversation(user)
        return list(reversed(self.run("recent_messages", {"conv": conv, "n": n}, many=True)))

    # ---- long-term memory ----
    def remember(self, user, text, kind="fact", importance=0.5):
        text = text.strip()[:500]
        if not text:
            return None
        self.run("insert_memory", {"user": user, "kind": kind, "text": text, "importance": importance})
        row = self.run("find_memory", {"user": user, "kind": kind, "text": text}, one=True)
        mid = row["id"]
        vec, norm = embed(text)
        if norm:
            with self.lock:
                for dim, val in vec:
                    self.db.execute(self.q["insert_vec"], {"id": mid, "dim": dim, "val": val})
                self.db.execute(self.q["insert_norm"], {"id": mid, "norm": norm})
                self.db.commit()
        return mid

    def search(self, user, query, k=5):
        vec, norm = embed(query)
        rows = self.run("search_hybrid", {"user": user, "qvec": json.dumps(vec), "qnorm": norm or 1.0, "fts": fts_query(query), "k": k}, many=True)
        rows = [r for r in rows if r["score"] > 0.12]
        for r in rows:
            self.run("touch_memory", {"id": r["id"], "user": user})
        return rows

    def list(self, user, n=100):
        return self.run("list_memories", {"user": user, "n": n}, many=True)

    def forget(self, user, mid):
        self.run("delete_memory", {"id": mid, "user": user})

    def stats(self, user):
        return self.run("memory_stats", {"user": user}, one=True)

    # ---- device log ----
    def log_device(self, user, device, command, ok, result):
        self.run("log_device", {"user": user, "device": device, "command": command, "ok": 1 if ok else 0, "result": result[:500]})

    def device_log(self, n=20):
        return self.run("recent_device_log", {"n": n}, many=True)
