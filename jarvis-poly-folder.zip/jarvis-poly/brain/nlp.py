"""Language understanding that runs before the LLM: device intents and facts worth remembering."""
import re

N = r"(\d{1,3})"


def _clean(s):
    return re.sub(r"\s+", " ", s).strip(" .,!?:;\"'")[:120]


def parse_device_intents(text):
    """Turn requests like 'turn off the light' into hub commands. Returns a list of dicts."""
    t = " " + text.lower() + " "
    out = []

    def add(device, props, confirm=False):
        out.append({"action": "set", "device": device, "props": props, "confirm": confirm})

    if re.search(r"\b(emergency stop|e-?stop|stop the robot|halt the robot|stop the arm)\b", t):
        return [{"action": "estop"}]
    if re.search(r"\b(resume|restart|release) the (robot|arm)\b", t):
        return [{"action": "resume"}]
    m = re.search(r"\b(?:turn|switch)\s+(on|off)\s+(?:the\s+)?(?:living\s*room\s+)?lights?\b", t) or re.search(r"\blights?\s+(on|off)\b", t)
    if m:
        add("light_living", {"on": 1 if m.group(1) == "on" else 0})
    m = re.search(r"\b(?:dim|set|change|make)\s+(?:the\s+)?(?:living\s*room\s+)?lights?\s*(?:brightness|level)?\s*(?:to|at)?\s*" + N + r"\s*(?:%|percent)?", t)
    if m:
        add("light_living", {"on": 1, "level": int(m.group(1))})
    m = re.search(r"\b(?:set|make|change|turn)\s+(?:the\s+)?(?:thermostat|temperature|heating|heat|ac)\s*(?:to|at)?\s*" + N + r"\b", t)
    if m:
        add("thermostat", {"setpoint": int(m.group(1))})
    if re.search(r"\block\s+(?:the\s+)?(?:front\s+)?door\b", t) and not re.search(r"\bunlock\b", t):
        add("door_lock", {"locked": 1})
    if re.search(r"\bunlock\s+(?:the\s+)?(?:front\s+)?door\b", t):
        add("door_lock", {"locked": 0}, confirm=bool(re.search(r"\bconfirm(ed)?\b", t)))
    if re.search(r"\b(raise|lift)\s+(?:the\s+)?(?:robot\s+)?arm\b", t):
        add("robot_arm", {"j2": 90})
    if re.search(r"\blower\s+(?:the\s+)?(?:robot\s+)?arm\b", t):
        add("robot_arm", {"j2": 0})
    m = re.search(r"\b(?:rotate|turn|swing)\s+(?:the\s+)?(?:robot\s+)?arm\s+(left|right)(?:\s+(?:by\s+)?" + N + r")?", t)
    if m:
        deg = int(m.group(2) or 45)
        add("robot_arm", {"j1": -deg if m.group(1) == "left" else deg})
    if re.search(r"\bopen\s+(?:the\s+)?gripper\b", t):
        add("robot_arm", {"gripper": 100})
    if re.search(r"\bclose\s+(?:the\s+)?gripper\b", t):
        add("robot_arm", {"gripper": 0})
    if re.search(r"\b(?:home|center|centre|reset)\s+(?:the\s+)?(?:robot\s+)?arm\b", t):
        add("robot_arm", {"j1": 0, "j2": 0, "j3": 0})
    return out


FACT_RULES = [
    (r"\bmy name is ([A-Za-z][\w'\- ]{1,40}?)(?:[.,!?]|\s+and\b|$)", "fact", lambda m: "The user's name is " + _clean(m.group(1))),
    (r"\bI (?:live|am living|stay) in ([^.,;!?]+)", "fact", lambda m: "The user lives in " + _clean(m.group(1))),
    (r"\bI (?:work|am working) (?:as|at|for) ([^.,;!?]+)", "fact", lambda m: "The user works as/at " + _clean(m.group(1))),
    (r"\bI (?:like|love|enjoy|prefer) ([^.,;!?]+)", "preference", lambda m: "The user likes " + _clean(m.group(1))),
    (r"\bI (?:hate|dislike|can't stand|cannot stand) ([^.,;!?]+)", "preference", lambda m: "The user dislikes " + _clean(m.group(1))),
    (r"\bmy fav(?:ou?rite) ([\w ]{2,30}?) is ([^.,;!?]+)", "preference", lambda m: "The user's favourite %s is %s" % (_clean(m.group(1)), _clean(m.group(2)))),
    (r"\bremember (?:that )?(.{3,200})", "note", lambda m: _clean(m.group(1))),
]


def extract_facts(text):
    """Return [(kind, sentence), ...] worth keeping in long-term memory."""
    found = []
    for pat, kind, fmt in FACT_RULES:
        for m in re.finditer(pat, text, re.IGNORECASE):
            s = fmt(m)
            if len(s) > 8:
                found.append((kind, s))
    return found
