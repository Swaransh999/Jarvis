#!/usr/bin/env python3
"""Start Jarvis: builds the C++ real-time core if needed, then runs the Python brain and the web page.

    pip install -r requirements.txt
    python run.py          then open http://localhost:5000
"""
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
core = ROOT / "realtime"
if not (core / "jarvis_rt").exists():
    if shutil.which("g++") and shutil.which("make"):
        print("Building the C++ real-time core...")
        subprocess.run(["make", "-C", str(core)], check=False)
    else:
        print("g++/make not found: starting without the real-time core (devices and audio monitor will be offline).")

sys.path.insert(0, str(ROOT))
from brain import server  # noqa: E402

if __name__ == "__main__":
    server.main()
