JARVIS: ONE PROJECT, FOUR LANGUAGES, EACH DOING THE JOB IT IS BEST AT
=====================================================================

  Layer                          Language          Where                    What it does
  -----------------------------  ----------------  -----------------------  ------------------------------------------
  Data and memory                SQL (SQLite)      sql/schema.sql           conversations, long-term memories, full-text
                                                   sql/queries.sql          index, vector index, device log. Retrieval is
                                                                            ONE SQL query: cosine similarity + BM25 + importance.
  Real-time processing           C++17             realtime/dsp.hpp         audio frames: level, FFT spectrum, speech start/end
  (audio streams, robots, IoT)                     realtime/hub.hpp         devices: light, thermostat, door lock, robot arm with
                                                   realtime/rt_main.cpp     hard limits, speed limits, emergency stop; 50 Hz loop
  Brain and AI logic             Python (Flask)    brain/server.py          API, login, plans, Gemini + ElevenLabs
                                                   brain/orchestrator.py    LLM orchestration: memory + device context -> prompt
                                                   brain/nlp.py             language rules: device intents, facts worth remembering
                                                   brain/memory.py          runs the SQL; brain/rt_client.py talks to C++
  User interface and agents      HTML / CSS / JS   public/index.html ...    chat, 3D animated background, live mode, login, plans
                                                   public/dashboard.html    web dashboard: devices, audio monitor, memory

HOW A MESSAGE FLOWS
  Browser (HTML/JS) -> Python brain -> SQL memory lookup (relevant things Jarvis remembers)
                                    -> C++ core (if the owner said "turn off the light", it acts, within safety limits)
                                    -> Gemini (gets the memories and the device results as context)
                                    <- answer streamed back, then stored in SQL
  Dashboard audio: browser mic -> Python -> C++ (speech detection + spectrum) -> bars and speech badge.

RUN IT
  pip install -r requirements.txt
  python run.py            (builds the C++ core with g++/make the first time, then starts everything)
  open http://localhost:5000        dashboard: http://localhost:5000/dashboard.html
  Without a compiler Jarvis still runs; only devices and the audio monitor are offline.
  Build or test the C++ core by hand:   make -C realtime test

TEST EVERYTHING (no keys or internet needed; network calls are faked)
  python tests/test_all.py         48 checks across all four layers

KEYS AND SETTINGS: keys.env (plain NAME=value, no quotes). Same file as the Python version.
  Sign-in setup for Google, Meta and Adobe: SIGNIN-SETUP.md. Owner login: NeutronKingSwaransh.

SAFETY RULES BUILT IN
  * Devices can only be controlled by the owner account (chat or dashboard). Normal users get 403.
  * Every command is clamped to the device's limits; the robot arm moves at a capped speed, never instantly.
  * Emergency stop freezes the arm and refuses robot commands until Resume. Say "emergency stop" in chat or press the button.
  * Unlocking the door is refused unless the user says "confirm" (chat) or confirms in a dialog (dashboard).
  * The C++ core listens on 127.0.0.1 only. Device commands are logged in SQL.
  * Memory is private per user. Say "remember that ..." to store something; "Forget" on the dashboard removes it.

TRY THESE IN CHAT (as the owner)
  "Remember that my favourite colour is blue"  ...later...  "What is my favourite colour?"
  "Turn off the light"   "Set the thermostat to 24"   "Rotate the robot arm left 30"   "Open the gripper"
  "Unlock the door"  (refused)   "Unlock the door, confirmed"   "Emergency stop"   "Resume the robot"

THE DEVICES ARE VIRTUAL
  light_living, thermostat, door_lock and robot_arm are simulated inside realtime/hub.hpp. To drive real hardware,
  replace the body of Hub::tick() and the property writes with your device drivers (GPIO, serial, MQTT, ...).
  The safety limits, emergency stop and protocol stay the same.

NOTES AND LIMITS
  * Memory embeddings are local word-hashing vectors: they find related wording, not deep meaning, and cost nothing.
    To use Gemini embeddings instead, change embed() in brain/memory.py; the SQL does not change.
  * Speech detection is energy and spectrum based (works well for clean mic audio; not a neural VAD).
  * Netlify cannot run this (it needs Python and a C++ process). Run it on your computer, or on a host where you can run
    a command (Render, Railway, a VPS). The C++ core and the Python brain must run on the same machine.
