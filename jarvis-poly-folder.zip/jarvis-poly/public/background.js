// 3D HUD background: gyroscope rings, holographic core, flight-through starfield, perspective grid, orbiting cubes, gold swirl
(()=>{
const cv=$('#bg'),c=cv.getContext('2d'),CY='107,228,255',OR='255,154,60',GD='255,196,90',rnd=Math.random,TAU=6.2832;
const still=matchMedia('(prefers-reduced-motion:reduce)').matches;
let W,H,R,cx,cy,D;
const rs=()=>{const d=Math.min(devicePixelRatio||1,2);W=innerWidth;H=innerHeight;cv.width=W*d;cv.height=H*d;c.setTransform(d,0,0,d,0,0);R=Math.min(W,H*.85)*.36;cx=W/2;cy=H*.42;D=R*3.2};
addEventListener('resize',rs);rs();
let camY=0,camP=-.12,camZ=1,zu=1,zs=1,ZF=1,yaw=0,pit=0,cyw=1,syw=0,cp=1,sp_=0,X,Y,Z,S,RX,RY,RZ;
const PRE={front:[0,-.12],top:[0,1.15],side:[1.25,-.1],low:[0,-.6],angle:[.75,.35]};
window.JVcam={set(k){const p=PRE[k];if(p){camY=p[0];camP=p[1]}},reset(){camY=0;camP=-.12;camZ=1},zoom(f){zoomTo(camZ*f)}};
const ptr=new Map();let pinch=0;
const free=e=>/\b(cam|live|gate)\b/.test(document.body.className)?!e.target.closest('#camui,#liveui,#gate,#mv,#pv'):!e.target.closest('.m,header,form,aside,#pv,#camui,button,textarea,a,#tray,#am');
const zoomTo=z=>{camZ=Math.min(2.6,Math.max(.5,z))};
addEventListener('pointerdown',e=>{
  if(!free(e))return;ptr.set(e.pointerId,[e.clientX,e.clientY]);
  if(ptr.size===2){const[a,b]=[...ptr.values()];pinch=Math.hypot(a[0]-b[0],a[1]-b[1])}
});
addEventListener('pointermove',e=>{
  const p=ptr.get(e.pointerId);if(!p)return;
  const dx=e.clientX-p[0],dy=e.clientY-p[1];p[0]=e.clientX;p[1]=e.clientY;
  if(ptr.size===2){const[a,b]=[...ptr.values()],d=Math.hypot(a[0]-b[0],a[1]-b[1]);if(pinch)zoomTo(camZ*d/pinch);pinch=d}
  else{camY+=dx*.008;camP=Math.min(1.4,Math.max(-1.4,camP+dy*.006))}
});
const up=e=>{ptr.delete(e.pointerId);pinch=0};
addEventListener('pointerup',up);addEventListener('pointercancel',up);
addEventListener('wheel',e=>{if(free(e))zoomTo(camZ*Math.exp(-e.deltaY*.0012))},{passive:true});
addEventListener('dblclick',e=>{if(free(e))JVcam.reset()});
const A=(col,a)=>'rgba('+col+','+Math.min(1,Math.max(0,a))+')';
function proj(x,y,z){const x1=x*cyw+z*syw,z1=z*cyw-x*syw,y2=y*cp-z1*sp_,z2=y*sp_+z1*cp;S=ZF*D/(D+z2);X=cx+x1*S;Y=cy+y2*S;Z=z2}
function rx3(x,y,z,a,b,g){
  let t=y*Math.cos(a)-z*Math.sin(a);z=y*Math.sin(a)+z*Math.cos(a);y=t;
  t=x*Math.cos(b)+z*Math.sin(b);z=z*Math.cos(b)-x*Math.sin(b);x=t;
  t=x*Math.cos(g)-y*Math.sin(g);y=x*Math.sin(g)+y*Math.cos(g);x=t;RX=x;RY=y;RZ=z;
}
const rot=(x,y,z,a,b,g)=>{rx3(x,y,z,a,b,g);proj(RX,RY,RZ)};
function ring3(r,a,b,g,col,lw,n,on,off,al){
  const per=on+off;let px,py;
  for(let i=0;i<=n;i++){
    const t=i/n*TAU;rot(Math.cos(t)*r,Math.sin(t)*r,0,a,b,g);
    if(i&&(i-1)%per<on){c.strokeStyle=A(col,al*(.6-.45*Z/r));c.lineWidth=lw*S;c.beginPath();c.moveTo(px,py);c.lineTo(X,Y);c.stroke()}
    px=X;py=Y;
  }
}
const stars=Array.from({length:170},()=>({x:(rnd()-.5)*8,y:(rnd()-.5)*5,z:rnd()*10-1.4,c:rnd()<.15?OR:rnd()<.1?GD:CY}));
const cubes=Array.from({length:10},()=>({a:rnd()*7,r:1.1+rnd()*1.4,y:(rnd()-.5)*1.4,s:.05+rnd()*.07,v:(.05+rnd()*.12)*(rnd()<.5?-1:1),o:rnd()*7,c:rnd()<.25?OR:CY}));
const swirl=Array.from({length:120},()=>({a:rnd()*7,r:.4+rnd()*.7,v:(.3+rnd()*.7)*(rnd()<.5?-1:1),o:rnd()*7}));
const N=320,pts=Array.from({length:N},(_,i)=>{const y=1-2*(i+.5)/N,r=Math.sqrt(1-y*y),th=i*2.39996;return[Math.cos(th)*r,y,Math.sin(th)*r]});
const V=[[-1,-1,-1],[1,-1,-1],[1,1,-1],[-1,1,-1],[-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1]],E=[[0,1],[1,2],[2,3],[3,0],[4,5],[5,6],[6,7],[7,4],[0,4],[1,5],[2,6],[3,7]],vx=[],vy=[];
const buf=new Uint8Array(128);
const lvl=()=>{if(!an)return 0;an.getByteFrequencyData(buf);let s=0;for(const v of buf)s+=v;return Math.min(1,s/buf.length/90)};
function line(x0,y0,x1,y1,col,lw){c.strokeStyle=col;c.lineWidth=lw;c.beginPath();c.moveTo(x0,y0);c.lineTo(x1,y1);c.stroke()}
let t=0,ph=0,kk=0,sw=0,last=performance.now();
function grid(){
  const gy=R*1.15,step=R*.45,z0=-R*1.2,span=R*8,tot=span-z0,off=(ph*R*.35)%step;
  for(let i=-9;i<=9;i++){
    proj(i*step,gy,z0);const x0=X,y0=Y;proj(i*step,gy,span);
    line(x0,y0,X,Y,A(CY,.24*(1-Math.abs(i)/10)),1);
  }
  for(let j=0;j<22;j++){
    const z=z0+(((j*step-off)%tot)+tot)%tot;
    proj(-9*step,gy,z);const x0=X,y0=Y;proj(9*step,gy,z);
    line(x0,y0,X,Y,A(CY,.3*(1-(z-z0)/tot)),1);
  }
}
function draw(dt,k,st,sp){
  yaw+=(camY+Math.sin(t*.25)*.06-yaw)*.12;pit+=(camP-pit)*.12;
  zu+=(camZ-zu)*.12;zs+=((st==='speaking'?1.2:1)-zs)*.04;ZF=zu*zs*(st==='speaking'?1+.015*Math.sin(t*4):1);
  cyw=Math.cos(yaw);syw=Math.sin(yaw);cp=Math.cos(pit);sp_=Math.sin(pit);
  c.globalCompositeOperation='source-over';
  c.fillStyle='#030a11';c.fillRect(0,0,W,H);
  const g=c.createRadialGradient(cx,cy,0,cx,cy,R*2.2*ZF);
  g.addColorStop(0,'rgba(20,70,95,'+(.45+k*.3)+')');g.addColorStop(1,'rgba(0,0,0,0)');c.fillStyle=g;c.fillRect(0,0,W,H);
  c.globalCompositeOperation='lighter';
  grid();
  // flight-through starfield
  for(const s of stars){
    s.z-=dt*(.22+(sp-1)*.35);
    if(s.z<-1.4){s.z=8.5;s.x=(rnd()-.5)*8;s.y=(rnd()-.5)*5}
    proj(s.x*R,s.y*R,s.z*R);const a=Math.min(1,(9-s.z)/6)*.85;
    if(sp>2){const x0=X,y0=Y;proj(s.x*R,s.y*R,(s.z+.5)*R);line(x0,y0,X,Y,A(s.c,a),Math.max(1,S))}
    else{const z=Math.max(1,S*1.6);c.fillStyle=A(s.c,a);c.fillRect(X-z/2,Y-z/2,z,z)}
  }
  // orbiting wireframe cubes
  for(const q of cubes){
    q.a+=q.v*dt*(1+(sp-1)*.5);
    const px=Math.cos(q.a)*q.r*R,pz=Math.sin(q.a)*q.r*R,py=q.y*R,sz=q.s*R;
    V.forEach((v,i)=>{rx3(v[0]*sz,v[1]*sz,v[2]*sz,t*.7+q.o,t*.5+q.o,0);proj(RX+px,RY+py,RZ+pz);vx[i]=X;vy[i]=Y});
    c.strokeStyle=A(q.c,.5);c.lineWidth=1;c.beginPath();E.forEach(e=>{c.moveTo(vx[e[0]],vy[e[0]]);c.lineTo(vx[e[1]],vy[e[1]])});c.stroke();
  }
  // gyroscope rings
  const q=1+k*.04;
  ring3(R*q,ph*.25+.9,ph*.15,0,CY,1.6,96,5,2,.7);
  ring3(R*.86*q,-ph*.2+.4,ph*.3,0,OR,3,72,9,3,.75);
  ring3(R*.7*q,ph*.35,-ph*.2+1.2,0,CY,2,90,90,0,.6);
  ring3(R*.5*q,1.1,ph*.5,ph*.2,CY,5,60,6,4,.6);
  ring3(R*.36*q,0,0,ph*.6,OR,6,50,4,4,.85);
  ring3(R*1.22,0,0,-ph*.05,CY,1,120,1,1,.5);
  // holographic core
  sw+=((st==='speaking'?1:st==='thinking'?.5:.08)-sw)*.05;
  const Rs=R*.2*(1+k*.12),mix=(107+148*sw|0)+','+(228-32*sw|0)+','+(255-165*sw|0);
  for(let i=0;i<N;i++){
    const p=pts[i],rr=Rs*(1+sw*.12*Math.sin(i*.7+t*6));
    rot(p[0]*rr,p[1]*rr,p[2]*rr,.35,ph*.3,0);
    c.fillStyle=A(mix,.25+.6*(.5-.5*Z/rr));c.beginPath();c.arc(X,Y,.8+1.6*S,0,TAU);c.fill();
  }
  ring3(Rs,.35,ph*.3,0,mix,1.2,60,60,0,.7);ring3(Rs,.35+1.5708,ph*.3,0,mix,1.2,60,60,0,.6);ring3(Rs,.35,ph*.3+1.5708,0,mix,1.2,60,60,0,.6);
  // radial spectrum (mic reactive)
  const live=st==='listening'&&an;
  for(let i=0;i<64;i++){
    const v=live?buf[(i*2)%128]/255:(.12+.5*k*Math.abs(Math.sin(i*.45+t*5)))*.7,a=i/64*TAU,r1=R*.58,r2=r1+R*(.03+v*.2);
    rot(Math.cos(a)*r1,Math.sin(a)*r1,0,0,0,ph*.1);const x0=X,y0=Y,s0=S;
    rot(Math.cos(a)*r2,Math.sin(a)*r2,0,0,0,ph*.1);
    line(x0,y0,X,Y,A(st==='speaking'?GD:CY,.35+v*.5),2*s0);
  }
  // gold swirl
  for(const p of swirl){
    p.a+=p.v*dt*(1+sw*2.5);const rr=R*p.r,al=sw*(.3+.7*Math.abs(Math.sin(t*3+p.o*9)));
    if(al<.02)continue;
    rot(Math.cos(p.a)*rr,Math.sin(p.a*3+p.o)*rr*.22,Math.sin(p.a)*rr,.45,ph*.05,.2);const x0=X,y0=Y;
    const b=p.a-Math.sign(p.v)*.08;rot(Math.cos(b)*rr,Math.sin(b*3+p.o)*rr*.22,Math.sin(b)*rr,.45,ph*.05,.2);
    line(x0,y0,X,Y,A(GD,al),1.3);
  }
  // reactor core glow
  const rg=R*.3*ZF,gg=c.createRadialGradient(cx,cy,0,cx,cy,rg);
  gg.addColorStop(0,A(OR,.55+k*.4));gg.addColorStop(.4,A(CY,.18+k*.2));gg.addColorStop(1,A(CY,0));
  c.fillStyle=gg;c.fillRect(cx-rg,cy-rg,rg*2,rg*2);
  c.globalCompositeOperation='source-over';
}
function frame(now){
  const dt=Math.min(.05,(now-last)/1000);last=now;t+=dt;
  const st=document.body.dataset.st||'';let target=.12+.08*Math.sin(t),sp=1;
  if(st==='thinking'){target=.5;sp=3.5}
  else if(st==='speaking'){target=.45+.35*Math.sin(t*9)*Math.sin(t*3.1);sp=1.6}
  else if(st==='listening'){target=Math.max(.15,lvl()*1.6);sp=1.4}
  kk+=(target-kk)*.15;ph+=dt*sp;
  draw(dt,kk,st,sp);
  if(!still)requestAnimationFrame(frame);
}
requestAnimationFrame(frame);
})();
