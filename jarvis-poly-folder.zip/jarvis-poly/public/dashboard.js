// Jarvis dashboard: devices, audio monitor and memory. Talks to the Python brain under /api/.
const $=s=>document.querySelector(s);
let TOKEN='';try{TOKEN=localStorage.getItem('jarvis-token')||''}catch(e){}
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

async function api(path,body,raw){
  const h={Authorization:'Bearer '+TOKEN};
  let opt={method:(body===undefined&&!raw)?'GET':'POST',headers:h};
  if(raw){opt.body=raw.data;Object.assign(h,raw.headers)}
  else if(body!==undefined){h['content-type']='application/json';opt.body=JSON.stringify(body)}
  const r=await fetch('/api'+path,opt);
  let j={};try{j=await r.json()}catch(e){}
  if(!r.ok){const e=new Error(j.error||'Error '+r.status);e.status=r.status;throw e}
  return j;
}
const pill=(id,ok,text)=>{const p=$(id);p.className='pill '+(ok?'on':'off');p.textContent=text};

// ---------- devices ----------
const LABELS={light_living:'Living room light',thermostat:'Thermostat',robot_arm:'Robot arm',door_lock:'Front door'};
let sliderBusy=0,owner=false;
function slider(dev,prop,p,unit){
  const v=Math.round(p.value*10)/10,t=Math.round(p.target*10)/10;
  return `<div class="row"><label>${esc(prop)}</label><input type="range" min="${p.min}" max="${p.max}" step="1" value="${t}" data-dev="${dev}" data-prop="${prop}" aria-label="${esc(LABELS[dev]+' '+prop)}"><output>${v}${unit} → ${t}</output></div>`;
}
function renderDevices(s){
  const d=s.devices,L=d.light_living.props,T=d.thermostat.props,A=d.robot_arm.props,K=d.door_lock.props;
  const html=`
  <div class="dev"><b>${LABELS.light_living}</b>
    <div class="row"><button data-set="light_living" data-k="on" data-v="${L.on.value>0.5?0:1}">${L.on.value>0.5?'Turn off':'Turn on'}</button></div>${slider('light_living','level',L.level,'%')}</div>
  <div class="dev"><b>${LABELS.thermostat}</b>${slider('thermostat','setpoint',T.setpoint,'°C')}<div class="row"><label>now</label><output style="width:auto">${T.current.value.toFixed(1)}°C</output></div></div>
  <div class="dev"><b>${LABELS.door_lock}</b><div class="row"><span class="badge ${K.locked.value>0.5?'speech':''}">${K.locked.value>0.5?'locked':'unlocked'}</span>
    <button data-set="door_lock" data-k="locked" data-v="1">Lock</button><button data-set="door_lock" data-k="locked" data-v="0" data-confirm="1">Unlock…</button></div></div>
  <div class="dev"><b>${LABELS.robot_arm}</b>${s.estop?'<span class="badge" style="color:var(--bad)">EMERGENCY STOP ACTIVE</span>':''}
    ${slider('robot_arm','j1',A.j1,'°')}${slider('robot_arm','j2',A.j2,'°')}${slider('robot_arm','j3',A.j3,'°')}${slider('robot_arm','gripper',A.gripper,'%')}</div>`;
  if(!sliderBusy)$('#devBody').innerHTML=html;
  $('#devLog').textContent=(s.log||[]).map(l=>`${l.created_at}  ${l.device}  ${l.ok?'ok':'REFUSED'}  ${l.result||''}`).join('\n');
}
async function pollDevices(){
  if(!owner)return;
  try{renderDevices(await api('/devices'));$('#devMsg').textContent=''}catch(e){$('#devMsg').textContent=e.message}
}
async function setDevice(device,props,confirm){
  try{
    const r=await api('/devices/set',{device,props,confirm});
    $('#devMsg').textContent=r.ok?'':'Refused: '+r.error.replace(/_/g,' ');
  }catch(e){$('#devMsg').textContent=e.message}
  pollDevices();
}
$('#devBody').addEventListener('input',e=>{if(e.target.matches('input[type=range]')){sliderBusy=1;e.target.nextElementSibling.textContent=e.target.value}});
$('#devBody').addEventListener('change',e=>{
  if(e.target.matches('input[type=range]')){sliderBusy=0;setDevice(e.target.dataset.dev,{[e.target.dataset.prop]:e.target.value})}
});
$('#devBody').addEventListener('click',e=>{
  const b=e.target.closest('[data-set]');if(!b)return;
  const confirm=b.dataset.confirm?window.confirm('Really unlock the front door?'):false;
  if(b.dataset.confirm&&!confirm)return;
  setDevice(b.dataset.set,{[b.dataset.k]:b.dataset.v},confirm);
});
$('#estop').onclick=async()=>{try{await api('/devices/estop',{});}catch(e){$('#devMsg').textContent=e.message}pollDevices()};
$('#resume').onclick=async()=>{try{await api('/devices/resume',{});}catch(e){$('#devMsg').textContent=e.message}pollDevices()};

// ---------- memory ----------
async function loadMemory(){
  const q=$('#memQ').value.trim();
  try{
    const r=await api('/memory'+(q?'?q='+encodeURIComponent(q):''));
    $('#memList').innerHTML=r.memories.length?r.memories.map(m=>`<div class="mem"><span>${esc(m.text)}<br><small>${esc(m.kind)} · ${esc(m.created_at)}${m.score!==undefined?' · match '+m.score.toFixed(2):''}</small></span><button data-del="${m.id}" aria-label="Forget this">Forget</button></div>`).join(''):'<p class="msg">Nothing here yet. Tell Jarvis "remember that…" in the chat.</p>';
    $('#memMsg').textContent='';
  }catch(e){$('#memMsg').textContent=e.message}
}
$('#memGo').onclick=loadMemory;
$('#memQ').onkeydown=e=>{if(e.key==='Enter')loadMemory()};
$('#memAdd').onclick=async()=>{const t=$('#memNew').value.trim();if(!t)return;try{await api('/memory',{text:t});$('#memNew').value='';loadMemory()}catch(e){$('#memMsg').textContent=e.message}};
$('#memList').addEventListener('click',async e=>{const b=e.target.closest('[data-del]');if(!b)return;await api('/memory/delete',{id:+b.dataset.del});loadMemory()});

// ---------- audio monitor: browser mic -> Python -> C++ core ----------
const bars=$('#bars');bars.innerHTML='<i></i>'.repeat(8);
let ctx=null,stream=null,proc=null,inflight=false,pending=[],acc=0,speechState=false;
function logAudio(t){const l=$('#audioLog');l.textContent=(new Date().toLocaleTimeString()+'  '+t+'\n'+l.textContent).split('\n').slice(0,30).join('\n')}
function paintAudio(r){
  $('#level').style.width=Math.max(0,Math.min(100,(r.rms_db+80)/80*100))+'%';
  [...bars.children].forEach((el,i)=>{el.style.height=Math.max(2,r.bands[i]*100)+'%'});
  const b=$('#speechBadge');b.className='badge'+(r.speech?' speech':'');b.textContent=r.speech?'speech':'silence';
  if(r.event)logAudio(r.event.replace('_',' ')+'  ('+r.rms_db.toFixed(0)+' dB)');
}
async function startMic(){
  try{stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:false,noiseSuppression:false}})}
  catch(e){$('#audioInfo').textContent='Microphone blocked: '+e.message;return}
  ctx=new (window.AudioContext||window.webkitAudioContext)();
  const src=ctx.createMediaStreamSource(stream),ratio=ctx.sampleRate/16000;
  proc=ctx.createScriptProcessor(2048,1,1);
  let frac=0;
  proc.onaudioprocess=ev=>{
    const x=ev.inputBuffer.getChannelData(0);
    for(let i=0;i<x.length;i++){frac+=1;if(frac>=ratio){frac-=ratio;pending.push(Math.max(-1,Math.min(1,x[i]))*32767)}}
    if(pending.length>=1600&&!inflight){
      const pcm=new Int16Array(pending.splice(0,pending.length));
      inflight=true;
      api('/audio',undefined,{data:pcm.buffer,headers:{'content-type':'application/octet-stream','X-Sample-Rate':'16000'}}).then(paintAudio).catch(e=>{$('#audioInfo').textContent=e.message}).finally(()=>{inflight=false});
    }
  };
  src.connect(proc);proc.connect(ctx.destination);
  $('#micBtn').textContent='Stop microphone';
}
function stopMic(){
  if(proc){proc.disconnect();proc=null}
  if(stream){stream.getTracks().forEach(t=>t.stop());stream=null}
  if(ctx){ctx.close();ctx=null}
  pending=[];$('#micBtn').textContent='Start microphone';
}
$('#micBtn').onclick=()=>stream?stopMic():startMic();

// ---------- start ----------
async function status(){
  try{
    const s=await api('/system');owner=s.owner;
    pill('#pBrain',true,'Brain (Python '+s.brain.python+')');
    pill('#pRt',s.realtime.ok,'Real-time (C++) '+(s.realtime.ok?'online':'offline'));
    pill('#pMem',true,'Memory (SQL): '+s.memory.memories+' memories');
    if(!owner)$('#devices').innerHTML='<h2>Devices</h2><p class="msg">Device control is for the owner account.</p>';
    return true;
  }catch(e){return false}
}
(async()=>{
  if(!TOKEN||!(await status())){$('#gate').hidden=false;return}
  $('#app').hidden=false;
  loadMemory();pollDevices();
  setInterval(pollDevices,500);setInterval(status,5000);
})();
