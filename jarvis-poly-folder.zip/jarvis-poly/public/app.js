const $=s=>document.querySelector(s);
const SYS="You are Jarvis, a professional, highly capable AI assistant. You answer anything, write any code and build anything the user asks for, generating everything live with no canned responses. Reply in the user's language and keep prose clear and concise. Put code in properly labelled fences.";
const MODES={
  quick:{n:'Quick',s:'Quick',d:'Short, instant answers',p:'Ask a quick question…',sys:'Answer in one to three sentences. Be direct.'},
  fast:{n:'Fast',s:'Fast',d:'Balanced speed and quality',p:'Ask Jarvis…',sys:''},
  think:{pro:1,n:'Deep thinking',s:'Deep thinking',d:'Careful reasoning for hard problems',p:'Ask something hard…',sys:'Reason step by step before answering, double-check your work, then give a thorough, well-structured answer.'},
  media:{pro:1,n:'Image and Video Generation',s:'Image/Video',d:'Describe it and Jarvis creates it',p:'Describe an image, or start with “video of…”',sys:''},
  build:{pro:1,n:'Build',s:'Build',d:'Full apps, games and sites with live preview',p:'Describe what to build…',sys:'You are in Build mode. Reply with one complete, polished, self-contained HTML file (inline CSS and JS, no external dependencies) in a single ```html block so it runs in the live preview, then add a two-line usage note.'}
};
let mode='fast',cur=null,chats=[],hist=[],busy=false,audio=null,talking=false,rec=null,an=null,ac=null,ME={plan:'free'},TOKEN='',CFG={},LOC='';

const setState=s=>{document.body.dataset.st=s||'';const t=$('#lst');if(t)t.textContent={thinking:'Thinking…',speaking:'Speaking…',listening:'Listening…'}[s]||''};
const toEnd=()=>{const l=$('#log');l.scrollTop=l.scrollHeight};
const esc=s=>s.replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
const inline=s=>esc(s).replace(/`([^`\n]+)`/g,'<code>$1</code>').replace(/\*\*([^*\n]+)\*\*/g,'<b>$1</b>').replace(/\n/g,'<br>');
function render(t){
  let o='',i=0,m;const re=/```(\w*)[^\S\n]*\n?([\s\S]*?)(```|$)/g;
  while((m=re.exec(t))){
    o+=inline(t.slice(i,m.index));
    const l=(m[1]||'code').toLowerCase(),run=l==='html'||l==='svg';
    o+='<div class="cb" data-l="'+l+'"><div class="ch"><span>'+l+'</span><span>'+(run?'<button data-act="run">Run</button>':'')+'<button data-act="copy">Copy</button><button data-act="save">Save</button></span></div><pre><code>'+esc(m[2])+'</code></pre></div>';
    i=re.lastIndex;
  }
  return o+inline(t.slice(i));
}
function addMsg(cls,text){
  const e=$('#empty');if(e&&cls!=='note')e.remove();
  const d=document.createElement('div');d.className='m '+cls;
  if(cls==='ai')d.innerHTML=render(text);else d.textContent=text;
  $('#log').appendChild(d);toEnd();return d;
}
const note=t=>addMsg('note',t);

// All AI calls go through the Jarvis server, which holds the keys and checks the plan.
async function api(path,body,opt){
  const o=opt||{},h={};if(TOKEN)h.Authorization='Bearer '+TOKEN;if(body!==undefined)h['content-type']='application/json';
  let r;try{r=await fetch('/api'+path,{method:body!==undefined?'POST':'GET',headers:h,body:body!==undefined?JSON.stringify(body):undefined})}catch(e){throw new Error('Can’t reach the Jarvis server. Check your connection, or that python app.py is running.')}
  if(r.status===401&&TOKEN&&!o.quiet){TOKEN='';store('jarvis-token');location.reload();throw new Error('Please log in again.')}
  if(!r.ok){
    let m='Error '+r.status,j=null;try{j=await r.clone().json()}catch(e){}
    if(j&&j.error)m=j.error;
    else if(r.status===404)m='The Jarvis server isn’t connected (error 404). Make sure python app.py is running. See the README.';
    else if(r.status>=500)m='The Jarvis server had a problem (error '+r.status+').';
    const e=new Error(m);e.status=r.status;throw e;
  }
  return r;
}
const apiJ=async(p,b,o)=>(await api(p,b,o)).json();
async function stream(onTok){
  const contents=hist.slice(-30).map(m=>({role:m.role==='user'?'user':'model',parts:[...(m.att||[]).map(x=>({inlineData:{mimeType:x.mime,data:x.data}})),{text:m.content}]}));
  const r=await api('/chat',{mode,contents,loc:LOC});
  const rd=r.body.getReader(),dec=new TextDecoder();
  for(;;){const {done,value}=await rd.read();if(done)break;onTok(dec.decode(value,{stream:true}))}
}
async function genImage(prompt,files){
  return apiJ('/image',{prompt,photos:(files||[]).filter(x=>x.kind==='photo').map(x=>({mime:x.mime,data:x.data}))});
}
async function genVideo(prompt,onStatus){
  const {op}=await apiJ('/video',{prompt});
  for(let i=1;i<=60;i++){
    await new Promise(z=>setTimeout(z,10000));
    onStatus('Rendering video… '+i*10+'s');
    const p=await apiJ('/video',{op});
    if(p.error)throw new Error(p.error);
    if(p.done)return URL.createObjectURL(await (await api('/videofile?uri='+encodeURIComponent(p.uri))).blob());
  }
  throw new Error('The video took too long. Please try again.');
}

function addUser(text,a){
  const d=document.createElement('div');d.className='m user';
  if(a&&a.length){const w=document.createElement('div');w.className='ua';a.forEach(x=>{const e=document.createElement(x.kind==='photo'?'img':'video');e.src=x.url;if(x.kind==='video'){e.controls=true;e.muted=true}w.appendChild(e)});d.appendChild(w)}
  d.appendChild(document.createTextNode(text));
  $('#log').appendChild(d);toEnd();
}
function notify(t,b){try{if('Notification' in window&&Notification.permission==='granted'&&document.hidden)new Notification(t,{body:b})}catch(e){}}
async function doChat(text,el,a){
  ensureChat(text);hist.forEach(m=>delete m.att);
  const tag=a.length?'\n['+a.map(x=>x.kind).join(', ')+' attached]':'';
  hist.push({role:'user',content:text+tag,att:a.length?a:undefined});let out='';
  try{
    await stream(t=>{out+=t;el.innerHTML=render(out);toEnd()});
    if(!out.trim())throw new Error('Empty reply. Please try again.');
  }catch(e){hist.pop();throw e}
  hist.push({role:'assistant',content:out});
  cur.msgs.push({r:'user',t:text+tag},{r:'ai',t:out});commit();
  speak(out);
  if(mode==='build'){const m=out.match(/```html[^\n]*\n([\s\S]*?)```/);if(m){openPreview('html',m[1]);notify('Jarvis','Your build is ready.')}}
}
async function doMedia(text,el,a){
  ensureChat(text);
  const photos=a.filter(x=>x.kind==='photo'),vid=/\b(video|clip|animat\w*|movie|footage|film)\b/i.test(text)&&!photos.length;
  const put=h=>{if(live){$('#mvc').innerHTML=h;$('#mv').hidden=false}else el.innerHTML=h};
  if(vid){
    el.innerHTML='<div class="gen">Starting video render. This can take a few minutes…</div>';
    const src=await genVideo(text,s=>{el.innerHTML='<div class="gen">'+s+'</div>'});
    put('<figure class="media"><video src="'+src+'" controls autoplay loop playsinline></video><button data-act="dl">Save video</button></figure>');
    notify('Jarvis','Your video is ready.');speak('Your video is ready.');
  }else{
    el.innerHTML='<div class="gen">'+(photos.length?'Editing your photo…':'Creating your image…')+'</div>';
    const r=await genImage(text,photos);
    put('<figure class="media"><img alt="Generated image" src="'+r.src+'">'+(r.text?'<p>'+inline(r.text)+'</p>':'')+'<button data-act="dl">Save image</button></figure>');
    speak('Here is your image.');
  }
  cur.msgs.push({r:'user',t:text},{r:'media',t:'Created '+(vid?'a video':'an image')+' for “'+text.slice(0,80)+'”. Images and videos aren’t kept in recent chats, so save them when you make them.'});commit();
  toEnd();
}
async function send(text,files){
  if(busy)return;
  text=(text||'').trim();
  if(!text&&!(files||atts).length)return;
  const a=files||atts.splice(0);if(!files)renderTray();
  if(!text)text='What do you see here?';
  closeMenu();stopAudio();addUser(text,a);
  const el=addMsg('ai','');busy=true;setState('thinking');
  try{await (mode==='media'?doMedia(text,el,a):doChat(text,el,a))}
  catch(e){el.innerHTML='<span class="err">'+esc(e.message||'Something went wrong.')+'</span>';if(e.status===402)openPlans(e.message)}
  busy=false;if(!talking)setState('');resume();
}

function stopAudio(){if(audio){audio.pause();audio=null}talking=false;setState('')}
async function speak(text){
  const clean=text.replace(/```[\s\S]*?(```|$)/g,' The code is on screen. ').replace(/[*_`#>]/g,'').trim().slice(0,1200);
  if(!clean)return;
  talking=true;setState('speaking');
  try{
    const r=await api('/tts',{text:clean});
    const a=new Audio(URL.createObjectURL(await r.blob()));audio=a;
    await new Promise((res,rej)=>{
      a.onended=()=>{if(audio===a){audio=null;talking=false;setState('')}res()};
      a.onerror=()=>rej(new Error('Audio playback failed.'));
      a.play().catch(rej);
    });
    resume();
  }catch(e){audio=null;talking=false;setState('');note(e.message);resume()}
}

// Microphone: permission + level analyser (drives the background)
async function enableMic(){
  if(an)return true;
  try{
    const st=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true}});
    ac=new (window.AudioContext||window.webkitAudioContext)();
    const src=ac.createMediaStreamSource(st);an=ac.createAnalyser();an.fftSize=256;src.connect(an);
    $('#mic').classList.add('live');const a=$('#allow');if(a)a.remove();
    return true;
  }catch(e){note('Microphone blocked. Allow it in your browser’s site settings and reload.');return false}
}
const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
async function mic(){
  if(!SR){note('Voice input isn’t supported in this browser. Try Chrome or Safari.');return}
  if(rec){rec.stop();return}
  if(!(await enableMic()))return;
  stopAudio();
  const r=new SR(),base=$('#in').value;rec=r;r.lang=navigator.language||'en-US';r.interimResults=true;
  r.onresult=e=>{let t='';for(const x of e.results)t+=x[0].transcript;$('#in').value=(base?base+' ':'')+t;$('#in').dispatchEvent(new Event('input'))};
  r.onend=()=>{rec=null;setState('');$('#mic').classList.remove('rec');$('#in').focus()};
  r.onerror=()=>{};
  setState('listening');$('#mic').classList.add('rec');r.start();
}

function openPreview(l,code){
  $('#pf').srcdoc=l==='svg'?'<body style="margin:0;display:grid;place-items:center;min-height:100vh">'+code+'</body>':code;
  $('#pv').hidden=false;
}

// Mode menu
const ddm=$('#ddm'),ddb=$('#ddb');
function renderMenu(){
  ddm.innerHTML=Object.entries(MODES).map(([k,m])=>'<button role="option" data-m="'+k+'"'+(k===mode?' class="on"':'')+'><b>'+m.n+(m.pro&&ME.plan==='free'?' <em>Pro</em>':'')+'</b><small>'+m.d+'</small></button>').join('');
}
renderMenu();
function closeMenu(){ddm.hidden=true;ddb.setAttribute('aria-expanded','false')}
function setMode(k){
  mode=k;$('#ddl').textContent=MODES[k].s;$('#in').placeholder=MODES[k].p;
  ddm.querySelectorAll('button').forEach(b=>b.classList.toggle('on',b.dataset.m===k));closeMenu();
}
ddb.onclick=e=>{e.stopPropagation();const open=ddm.hidden;ddm.hidden=!open;ddb.setAttribute('aria-expanded',String(open))};
ddm.onclick=e=>{const b=e.target.closest('button');if(!b)return;const k=b.dataset.m;if(!canUse(k)){closeMenu();openPlans('“'+MODES[k].n+'” is part of Jarvis Pro.');return}setMode(k)};
document.addEventListener('click',closeMenu);
addEventListener('keydown',e=>{if(e.key==='Escape'){closeMenu();closeDrawer();camMode(false);$('#plans').hidden=true;if(live)liveOff()}});
setMode('fast');

// UI wiring
$('#f').onsubmit=e=>{e.preventDefault();const v=$('#in').value;$('#in').value='';$('#in').style.height='';send(v)};
$('#in').oninput=e=>{e.target.style.height='auto';e.target.style.height=e.target.scrollHeight+'px'};
$('#in').onkeydown=e=>{if(e.key==='Enter'&&!e.shiftKey&&!/Mobi|Android/i.test(navigator.userAgent)){e.preventDefault();$('#f').requestSubmit()}};
$('#mic').onclick=mic;
$('#orb').onclick=()=>{if(rec)rec.stop();else stopAudio()};
const EXT={html:'html',svg:'svg',python:'py',py:'py',javascript:'js',js:'js',typescript:'ts',css:'css',json:'json',java:'java',cpp:'cpp',c:'c',bash:'sh',sh:'sh'};
$('#log').addEventListener('click',e=>{
  const b=e.target.closest('[data-act]');if(!b)return;
  const act=b.dataset.act;
  if(act==='dl'){const mm=b.closest('.media').querySelector('img,video'),a=document.createElement('a');a.href=mm.src;a.download='jarvis-'+(mm.tagName==='IMG'?'image.png':'video.mp4');a.click();return}
  const box=b.closest('.cb'),code=box.querySelector('code').textContent,l=box.dataset.l;
  if(act==='copy'){navigator.clipboard.writeText(code).then(()=>{b.textContent='Copied';setTimeout(()=>b.textContent='Copy',1200)})}
  if(act==='save'){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([code]));a.download='jarvis.'+(EXT[l]||'txt');a.click()}
  if(act==='run')openPreview(l,code);
});
$('#pvx').onclick=()=>{$('#pv').hidden=true;$('#pf').srcdoc=''};

// ---------- Permissions, sign-in and sessions ----------
const PN2={google:'Google',anthropic:'Anthropic',meta:'Meta',adobe:'Adobe'};
const store=(k,v)=>{try{v===undefined?localStorage.removeItem(k):localStorage.setItem(k,v)}catch(e){}};
const getS=k=>{try{return localStorage.getItem(k)}catch(e){return null}};
const loadScript=src=>new Promise((ok,no)=>{const s=document.createElement('script');s.src=src;s.onload=ok;s.onerror=()=>no(new Error('Could not load sign-in. Check your connection.'));document.head.appendChild(s)});
function syncUI(){
  const off=/\b(cam|live|gate)\b/.test(document.body.className);
  document.querySelectorAll('header,#log,form,#tray').forEach(e=>{e.classList.toggle('hid',off);e.inert=off});
}
const PERM={
  async mic(){const s=await navigator.mediaDevices.getUserMedia({audio:true});s.getTracks().forEach(t=>t.stop())},
  async cam(){const s=await navigator.mediaDevices.getUserMedia({video:true});s.getTracks().forEach(t=>t.stop())},
  loc(){return new Promise((ok,no)=>navigator.geolocation?navigator.geolocation.getCurrentPosition(p=>{LOC=p.coords.latitude.toFixed(2)+', '+p.coords.longitude.toFixed(2);ok()},no,{timeout:15000}):no())},
  async not(){if(!('Notification' in window))throw 0;if(await Notification.requestPermission()!=='granted')throw 0}
};
const pbtn=k=>document.querySelector('[data-p="'+k+'"]');
async function ask(k){
  const b=pbtn(k);b.disabled=true;b.textContent='…';
  try{await PERM[k]();b.textContent='Allowed ✓';b.classList.add('ok')}catch(e){b.disabled=false;b.textContent='Retry'}
}
const PQ={mic:'microphone',cam:'camera',loc:'geolocation',not:'notifications'};
async function precheck(){
  for(const k in PQ){try{const p=await navigator.permissions.query({name:PQ[k]});if(p.state==='granted'){const b=pbtn(k);b.textContent='Allowed ✓';b.classList.add('ok');b.disabled=true}}catch(e){}}
}
document.querySelectorAll('[data-p]').forEach(b=>b.onclick=()=>ask(b.dataset.p));
$('#pall').onclick=async()=>{for(const k of Object.keys(PERM)){if(pbtn(k).classList.contains('ok'))continue;await ask(k)}};
$('#pgo').onclick=()=>{store('jarvis-onboarded','1');showLogin()};

const canUse=k=>!MODES[k].pro||ME.plan!=='free';
const ge=t=>{$('#ge').textContent=t||''};
function finish(r){TOKEN=r.token;store('jarvis-token',TOKEN);ME=r.user;enterApp()}
const ADOBE={url:'https://ims-na1.adobelogin.com/ims/authorize/v2',scope:'openid,AdobeID,email,profile'};
async function provToken(p){
  if(p==='anthropic')throw new Error('Anthropic doesn’t offer a public sign-in for websites yet. Use Jarvis Log in or another provider.');
  if(!CFG[p])throw new Error(PN2[p]+' sign-in isn’t set up on this site yet.');
  if(p==='google'){
    if(!window.google||!google.accounts)await loadScript('https://accounts.google.com/gsi/client');
    return new Promise((ok,no)=>google.accounts.oauth2.initTokenClient({client_id:CFG.google,scope:'openid email profile',callback:r=>r.access_token?ok(r.access_token):no(new Error('Google sign-in failed.')),error_callback:()=>no(new Error('Google sign-in was cancelled.'))}).requestAccessToken());
  }
  if(p==='meta'){
    if(!window.FB)throw new Error('Meta sign-in is still loading. Try again in a moment.');
    const r=await new Promise(ok=>FB.login(ok,{scope:'public_profile,email'}));
    if(!r.authResponse)throw new Error('Meta sign-in was cancelled.');
    return r.authResponse.accessToken;
  }
  const pop=window.open(ADOBE.url+'?client_id='+encodeURIComponent(CFG.adobe)+'&response_type=token&scope='+encodeURIComponent(ADOBE.scope)+'&redirect_uri='+encodeURIComponent(location.origin+location.pathname)+'&state='+Math.random().toString(36).slice(2),'jarvis-auth','width=480,height=680');
  if(!pop)throw new Error('Allow pop-ups to sign in.');
  return new Promise((ok,no)=>{
    const t0=Date.now(),iv=setInterval(()=>{
      let h='';
      try{if(pop.closed){clearInterval(iv);return no(new Error('Sign-in was cancelled.'))}h=pop.location.hash}catch(e){}
      if(h.includes('access_token')){clearInterval(iv);const t=new URLSearchParams(h.slice(1)).get('access_token');pop.close();return ok(t)}
      if(Date.now()-t0>180000){clearInterval(iv);try{pop.close()}catch(e){}no(new Error('Sign-in timed out.'))}
    },400);
  });
}
document.querySelectorAll('[data-a]').forEach(b=>b.onclick=async()=>{
  ge();try{finish(await apiJ('/oauth',{provider:b.dataset.a,token:await provToken(b.dataset.a)},{quiet:1}))}catch(e){ge(e.message)}
});
const tab=s=>{$('#lg').hidden=s;$('#sg').hidden=!s;$('#tl').classList.toggle('on',!s);$('#ts').classList.toggle('on',s);ge()};
$('#tl').onclick=()=>tab(false);$('#ts').onclick=()=>tab(true);
$('#lgo').onclick=async()=>{ge();try{finish(await apiJ('/login',{id:$('#li').value.trim(),password:$('#lw').value},{quiet:1}))}catch(e){ge(e.message)}};
$('#sgo').onclick=async()=>{ge();try{finish(await apiJ('/signup',{id:$('#si').value.trim(),email:$('#se').value.trim(),password:$('#sw').value},{quiet:1}))}catch(e){ge(e.message)}};
['li','lw'].forEach(i=>$('#'+i).onkeydown=e=>{if(e.key==='Enter')$('#lgo').click()});
['si','se','sw'].forEach(i=>$('#'+i).onkeydown=e=>{if(e.key==='Enter')$('#sgo').click()});

// Plans and subscriptions
function planText(){return ME.plan==='owner'?'Owner account: everything is unlocked and free.':ME.plan==='pro'?'Jarvis Pro is active'+(ME.interval?' ('+(ME.interval==='year'?'yearly':'monthly')+')':'')+'.':'You’re on the Free plan.'}
function paintPlans(){$('#pst').textContent=planText();$('#psub').hidden=ME.plan!=='free';$('#pmg').hidden=ME.plan!=='pro'}
function openPlans(msg){
  $('#pmsg').textContent=msg||'Unlock Deep thinking, Image and Video Generation and Build.';
  paintPlans();closeMenu();closeDrawer();$('#plans').hidden=false;
  apiJ('/me?fresh=1',undefined,{quiet:1}).then(m=>{ME=m;renderMenu();paintPlans()}).catch(()=>{});
}
async function go(path,body){try{location.href=(await apiJ(path,body)).url}catch(e){$('#pst').textContent=e.message}}
$('#sm').onclick=()=>go('/checkout',{interval:'month'});
$('#sy').onclick=()=>go('/checkout',{interval:'year'});
$('#pmg').onclick=()=>go('/portal',{});
$('#pcl').onclick=()=>{$('#plans').hidden=true};

async function health(){
  const el=$('#hs');let h=null;
  try{h=await (await fetch('/api/health?deep=1')).json()}catch(e){}
  const m=[];
  if(!h)m.push('The Jarvis server isn’t connected, so login can’t work yet. Start it with  python app.py  from the Jarvis folder (see README).');
  else{
    if(!h.jwt)m.push('Setup needed: JWT_SECRET is empty in keys.env.');
    const c=h.checks||{};
    if(c.gemini&&!c.gemini.ok)m.push('Gemini key problem'+(c.gemini.status?' ('+c.gemini.status+')':'')+': '+c.gemini.message+'. The server is using the key '+(h.hints||{}).gemini+'.');
    if(c.eleven&&!c.eleven.ok)m.push('ElevenLabs key problem'+(c.eleven.status?' ('+c.eleven.status+')':'')+': '+c.eleven.message+'. The server is using the key '+(h.hints||{}).eleven+'.');
    if(c.stripe&&!c.stripe.ok)m.push('Stripe key problem'+(c.stripe.status?' ('+c.stripe.status+')':'')+': '+c.stripe.message+'. The server is using the key '+(h.hints||{}).stripe+'. Normal accounts need a working Stripe key.');
  }
  el.textContent=m.join(' ');el.hidden=!m.length;
}
function showLogin(){
  $('#g1').hidden=true;$('#g2').hidden=false;health();
  apiJ('/config').then(c=>{
    CFG=c;
    if(c.google)loadScript('https://accounts.google.com/gsi/client').catch(()=>{});
    if(c.meta)loadScript('https://connect.facebook.net/en_US/sdk.js').then(()=>FB.init({appId:c.meta,version:'v21.0',cookie:true})).catch(()=>{});
  }).catch(()=>{});
}
function enterApp(){
  $('#gate').hidden=true;document.body.classList.remove('gate');syncUI();
  if(!canUse(mode))setMode('fast');else renderMenu();
  const n=ME.name||'Jarvis user',lab=ME.plan==='owner'?'Owner · everything unlocked':ME.plan==='pro'?'Jarvis Pro':'Free plan';
  $('#prof').innerHTML='<div class="pf"><span class="av">'+esc(n[0].toUpperCase())+'</span><div><b>'+esc(n)+'</b><small>'+lab+'</small></div><button id="pbtn">Plans</button><button id="so">Sign out</button></div>';
  $('#pbtn').onclick=()=>openPlans();
  $('#so').onclick=()=>{TOKEN='';store('jarvis-token');location.reload()};
  try{navigator.permissions.query({name:'geolocation'}).then(p=>{if(p.state==='granted')PERM.loc().catch(()=>{})})}catch(e){}
}
async function boot(){
  TOKEN=getS('jarvis-token')||'';
  const q=new URLSearchParams(location.search);
  if(TOKEN){
    try{
      ME=await apiJ('/me'+(q.has('sub')?'?fresh=1':''),undefined,{quiet:1});enterApp();
      if(q.get('sub')==='success')note(ME.plan==='free'?'Payment received. Your plan will unlock in a moment; reopen Plans to refresh.':'Welcome to Jarvis Pro! Deep thinking, Image and Video Generation and Build are unlocked.');
      if(q.has('sub'))history.replaceState(null,'',location.pathname);
      return;
    }catch(e){TOKEN='';store('jarvis-token')}
  }
  document.body.classList.add('gate');syncUI();$('#gate').hidden=false;
  if(getS('jarvis-onboarded'))showLogin();else{$('#g1').hidden=false;precheck()}
}

// ---------- Attachments: gallery and camera ----------
let atts=[];
const b64=f=>new Promise((ok,no)=>{const r=new FileReader();r.onload=()=>ok(String(r.result).split(',')[1]);r.onerror=no;r.readAsDataURL(f)});
function prepImage(f){
  return new Promise((ok,no)=>{
    const img=new Image(),u=URL.createObjectURL(f);
    img.onload=()=>{const k=Math.min(1,1600/Math.max(img.width,img.height)),c=document.createElement('canvas');c.width=img.width*k;c.height=img.height*k;c.getContext('2d').drawImage(img,0,0,c.width,c.height);URL.revokeObjectURL(u);const d=c.toDataURL('image/jpeg',.85);ok({kind:'photo',mime:'image/jpeg',data:d.split(',')[1],url:d,name:f.name})};
    img.onerror=()=>no();img.src=u;
  });
}
async function addFiles(files){
  for(const f of files){
    if(atts.length>=4){note('You can attach up to 4 files at a time.');break}
    try{
      if(f.type.startsWith('image/'))atts.push(await prepImage(f));
      else if(f.type.startsWith('video/')){
        if(f.size>3*1048576){note('“'+f.name+'” is over 3 MB. Please send a shorter clip.');continue}
        atts.push({kind:'video',mime:f.type==='video/quicktime'?'video/mov':f.type,data:await b64(f),url:URL.createObjectURL(f),name:f.name});
      }
    }catch(e){note('Couldn’t read “'+f.name+'”.')}
  }
  renderTray();
}
function renderTray(){
  const t=$('#tray');t.hidden=!atts.length;
  t.innerHTML=atts.map((a,i)=>'<div class="th">'+(a.kind==='photo'?'<img alt="" src="'+a.url+'">':'<video src="'+a.url+'" muted></video>')+'<button type="button" data-x="'+i+'" aria-label="Remove">✕</button></div>').join('');
}
const am=$('#am');
$('#att').onclick=e=>{e.stopPropagation();am.hidden=!am.hidden};
document.addEventListener('click',()=>{am.hidden=true});
am.onclick=e=>{const b=e.target.closest('[data-i]');if(b)$('#'+b.dataset.i).click()};
['fl','fp','fv'].forEach(id=>$('#'+id).onchange=e=>{addFiles([...e.target.files]);e.target.value=''});
$('#tray').onclick=e=>{const b=e.target.closest('[data-x]');if(b){atts.splice(+b.dataset.x,1);renderTray()}};

// ---------- Live mode: voice only ----------
let live=false,prevMode='fast';
function closeOverlays(){$('#pv').hidden=true;$('#pf').srcdoc='';$('#mv').hidden=true;$('#mvc').innerHTML=''}
$('#mvx').onclick=closeOverlays;
function resume(){if(live&&!busy&&!talking&&!rec)setTimeout(liveListen,250)}
function liveListen(){
  if(!live||busy||talking||rec)return;
  const r=new SR();rec=r;r.lang=navigator.language||'en-US';r.continuous=true;r.interimResults=false;let got=false;
  r.onresult=e=>{if(got)return;const x=e.results[e.results.length-1];if(!x.isFinal)return;got=true;const t=x[0].transcript.trim();r.stop();liveHandle(t)};
  r.onend=()=>{if(rec===r)rec=null;if(!got)resume()};
  r.onerror=e=>{if(e.error==='not-allowed'||e.error==='service-not-allowed'){note('Microphone access is blocked, so live mode can’t listen.');liveOff()}};
  setState('listening');
  try{r.start()}catch(e){rec=null;setTimeout(resume,600)}
}
async function snapFrame(){
  const st=await navigator.mediaDevices.getUserMedia({video:{facingMode:'environment'}});
  const v=document.createElement('video');v.srcObject=st;v.muted=true;v.playsInline=true;await v.play();
  await new Promise(r=>setTimeout(r,700));
  const c=document.createElement('canvas'),k=Math.min(1,1280/(v.videoWidth||1280));
  c.width=(v.videoWidth||1280)*k;c.height=(v.videoHeight||720)*k;c.getContext('2d').drawImage(v,0,0,c.width,c.height);
  st.getTracks().forEach(t=>t.stop());
  const d=c.toDataURL('image/jpeg',.85);
  return {kind:'photo',mime:'image/jpeg',data:d.split(',')[1],url:d,name:'camera.jpg'};
}
async function liveHandle(t){
  const s=(t||'').toLowerCase();
  if(!s)return resume();
  if(/(exit|end|stop|leave|close) (the )?live( mode)?|^(goodbye|bye)\b/.test(s)){await speak('Leaving live mode.');liveOff();return}
  if(/^(stop|quiet|be quiet|stop talking|cancel|never mind)\b/.test(s)){stopAudio();resume();return}
  const cv=s.match(/\b(top|side|front|low|angle)\b (view|angle|camera)/);
  if(cv){JVcam.set(cv[1]);await speak('Switching to the '+cv[1]+' view.');return}
  if(/zoom in/.test(s)){JVcam.zoom(1.3);await speak('Zooming in.');return}
  if(/zoom out/.test(s)){JVcam.zoom(.75);await speak('Zooming out.');return}
  if(/reset (the )?camera/.test(s)){JVcam.reset();await speak('Camera reset.');return}
  if(/(close|hide) (the )?(preview|image|video|picture|app)/.test(s)){closeOverlays();await speak('Closed.');return}
  if(/(new|start a new) (chat|conversation)/.test(s)){newChat();await speak('Starting fresh.');return}
  let a,tm='fast';
  if(/what (do|can) you see|look at (this|that|me|it)|what('s| is) (this|that|in front of me)|take a (photo|picture|look)|describe (this|what you see)/.test(s)){
    try{a=[await snapFrame()]}catch(e){await speak('I couldn’t open the camera.');return}
  }else if(/\b(generate|create|make|draw|paint|show me|imagine)\b.*\b(image|picture|photo|illustration|painting|video|animation|clip)\b/.test(s))tm='media';
  else if(/\b(build|code|program|develop|make|create)\b.*\b(app|game|website|web site|page|tool|calculator|dashboard|script|program)\b/.test(s))tm='build';
  if(!canUse(tm)){await speak('That needs Jarvis Pro.');return}
  setMode(tm);send(t,a);
}
async function liveOn(){
  if(!SR){note('Live mode needs speech recognition. Try Chrome or Safari.');return}
  if(!(await enableMic()))return;
  closeMenu();closeDrawer();camMode(false);stopAudio();
  prevMode=mode;live=true;
  document.body.classList.add('live');syncUI();$('#liveui').hidden=false;
  speak('Live mode on. I’m listening.');
}
function liveOff(){
  live=false;if(rec){rec.onend=null;try{rec.abort()}catch(e){}rec=null}
  stopAudio();closeOverlays();
  document.body.classList.remove('live');syncUI();$('#liveui').hidden=true;setMode(prevMode);setState('');
}
$('#liveb').onclick=liveOn;$('#livex').onclick=liveOff;

// Camera view: hides the chat so the whole screen can be dragged, pinched and scrolled
function camMode(on){
  document.body.classList.toggle('cam',on);$('#camui').hidden=!on;
  syncUI();
  if(on){closeMenu();closeDrawer()}
}
$('#camb').onclick=()=>camMode(true);
$('#camx').onclick=()=>camMode(false);
$('#camui').addEventListener('click',e=>{const b=e.target.closest('[data-v]');if(b)JVcam.set(b.dataset.v)});

// Recent chats (saved in this browser)
try{chats=JSON.parse(localStorage.getItem('jarvis-chats')||'[]')}catch(e){chats=[]}
function persist(){
  let l=chats.slice(0,40);
  for(;;){try{localStorage.setItem('jarvis-chats',JSON.stringify(l));break}catch(e){if(l.length<=1)break;l=l.slice(0,-1)}}
  chats=l;
}
function ensureChat(text){if(!cur)cur={id:Date.now(),title:text.slice(0,42),mode,t:Date.now(),msgs:[]}}
function commit(){cur.mode=mode;cur.t=Date.now();chats=[cur,...chats.filter(c=>c.id!==cur.id)];persist()}
const ago=ts=>{const m=Math.round((Date.now()-ts)/60000);return m<1?'just now':m<60?m+' min ago':m<1440?Math.round(m/60)+' h ago':Math.round(m/1440)+' d ago'};
function renderChats(){
  $('#rcl').innerHTML=chats.length?chats.map(c=>'<div class="ci'+(cur&&cur.id===c.id?' on':'')+'"><button class="go" data-open="'+c.id+'"><b>'+esc(c.title)+'</b><small>'+(MODES[c.mode]||MODES.fast).n+' · '+ago(c.t)+'</small></button><button data-del="'+c.id+'" aria-label="Delete chat">✕</button></div>').join(''):'<p class="none">No saved chats yet. Talk to Jarvis and your conversations will show up here.</p>';
}
function openDrawer(){renderChats();$('#rc').classList.add('open');$('#rc').setAttribute('aria-hidden','false');$('#rcv').hidden=false;$('#rcx').focus()}
function closeDrawer(){$('#rc').classList.remove('open');$('#rc').setAttribute('aria-hidden','true');$('#rcv').hidden=true}
function newChat(){
  if(busy){note('Jarvis is still working. Try again in a moment.');return}
  stopAudio();cur=null;hist=[];$('#log').innerHTML='';
}
function openChat(id){
  const c=chats.find(x=>x.id===id);if(!c)return;
  if(busy){closeDrawer();note('Jarvis is still working. Try again in a moment.');return}
  stopAudio();cur=c;
  hist=c.msgs.filter(m=>m.r==='user'||m.r==='ai').map(m=>({role:m.r==='user'?'user':'assistant',content:m.t}));
  $('#log').innerHTML='';
  c.msgs.forEach(m=>addMsg(m.r==='user'?'user':m.r==='ai'?'ai':'note',m.t));
  setMode(canUse(c.mode||'fast')?(c.mode||'fast'):'fast');closeDrawer();toEnd();
}
function delChat(id){
  chats=chats.filter(c=>c.id!==id);
  if(cur&&cur.id===id){cur=null;hist=[];$('#log').innerHTML=''}
  persist();renderChats();
}
$('#rcb').onclick=openDrawer;
$('#rcv').onclick=closeDrawer;$('#rcx').onclick=closeDrawer;
$('#rcn').onclick=()=>{newChat();closeDrawer()};
$('#rcl').onclick=e=>{
  const d=e.target.closest('[data-del]');if(d){delChat(+d.dataset.del);return}
  const o=e.target.closest('[data-open]');if(o)openChat(+o.dataset.open);
};
boot();
