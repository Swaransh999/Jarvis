#!/usr/bin/env python3
"""End-to-end tests for every layer: SQL memory, language rules, C++ core, and the Python server wiring them together.
Run:  python tests/test_all.py        (needs g++ the first time, to build the C++ core)
Network calls (Gemini, ElevenLabs, Stripe) are replaced by fakes, so no keys or internet are needed."""
import json, math, os, re, shutil, struct, subprocess, sys, tempfile, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
TMP = Path(tempfile.mkdtemp())
os.environ.update({"JARVIS_DB": str(TMP / "t.db"), "RT_PORT": "7893", "PYTHONDONTWRITEBYTECODE": "1"})

fails = []
def ok(label, cond):
    print(("PASS " if cond else "FAIL ") + label)
    if not cond: fails.append(label)

# ---------------- build the C++ core ----------------
exe = Path(os.environ.get("RT_BIN", ROOT / "realtime" / "jarvis_rt"))
if not os.access(exe, os.X_OK):
    exe = TMP / "jarvis_rt"
    subprocess.run(["g++", "-O2", "-std=c++17", "-Wall", "-Wextra", "-pthread", "-o", str(exe), str(ROOT / "realtime" / "rt_main.cpp")], check=True)
r = subprocess.run([str(exe), "--selftest"], capture_output=True, text=True)
ok("C++ self-test (%d checks)" % r.stdout.count("PASS"), r.returncode == 0 and "FAIL" not in r.stdout)

# ---------------- SQL memory + NLP ----------------
from brain import nlp
from brain.memory import Memory
mem = Memory(TMP / "m.db", ROOT / "sql")
for u in ("alice", "bob"): mem.ensure_user(u, u)
mem.remember("alice", "The user's favourite colour is blue", "preference", 0.8)
mem.remember("alice", "The user lives in Mumbai", "fact", 0.8)
mem.remember("alice", "Remember to buy milk on Friday", "note", 0.5)
mem.remember("bob", "The user's favourite colour is green", "preference", 0.8)
hit = mem.search("alice", "what is my favourite colour?")
ok("vector+keyword search finds the colour memory first", hit and "blue" in hit[0]["text"])
ok("search is private per user", all("green" not in h["text"] for h in hit) and "green" in mem.search("bob", "favourite colour")[0]["text"])
ok("keyword search works for rare words", mem.search("alice", "milk")[0]["text"].startswith("Remember to buy milk"))
ok("unrelated query returns nothing", mem.search("alice", "quantum chromodynamics lagrangian") == [])
mem.remember("alice", "The user lives in Mumbai", "fact", 0.8)
ok("duplicate memories are not stored twice", sum(1 for m in mem.list("alice") if "Mumbai" in m["text"]) == 1)
mid = mem.search("alice", "milk")[0]["id"]; mem.forget("alice", mid)
ok("forgetting removes it from search (FTS trigger)", mem.search("alice", "milk") == [])
mem.add_message("alice", "user", "hello"); mem.add_message("alice", "assistant", "hi there")
ok("conversation history is stored and ordered", [m["role"] for m in mem.recent("alice")] == ["user", "assistant"])
ok("memory stats", mem.stats("alice")["messages"] == 2)
ok("NLP: lights", nlp.parse_device_intents("please turn off the living room light")[0]["props"] == {"on": 0})
ok("NLP: dim", nlp.parse_device_intents("dim the lights to 30%")[0]["props"] == {"on": 1, "level": 30})
ok("NLP: thermostat", nlp.parse_device_intents("set the thermostat to 24")[0] == {"action": "set", "device": "thermostat", "props": {"setpoint": 24}, "confirm": False})
ok("NLP: unlock needs the word confirm", nlp.parse_device_intents("unlock the door")[0]["confirm"] is False and nlp.parse_device_intents("unlock the door, confirmed")[0]["confirm"] is True)
ok("NLP: robot arm", nlp.parse_device_intents("rotate the robot arm left 30")[0]["props"] == {"j1": -30})
ok("NLP: emergency stop wins", nlp.parse_device_intents("emergency stop, then turn on the light") == [{"action": "estop"}])
ok("NLP: ordinary chat triggers nothing", nlp.parse_device_intents("tell me a story about a robot arm in a factory") == [])
ok("NLP: facts", ("fact", "The user's name is Rupali") in nlp.extract_facts("Hi, my name is Rupali.") and any("Pune" in t for _, t in nlp.extract_facts("I live in Pune")))
ok("NLP: remember note", ("note", "my sister's birthday is on 4 May") in nlp.extract_facts("Remember that my sister's birthday is on 4 May"))

# ---------------- C++ core through the Python client ----------------
from brain.rt_client import RT
rt = RT(port=7894)
ok("Python starts and reaches the C++ core", rt.start(exe))
def tone(hz, amp, n=320, rate=16000): return b"".join(struct.pack("<h", int(amp * 32767 * math.sin(2 * math.pi * hz * i / rate))) for i in range(n))
ev = [rt.audio("s", 16000, tone(440, 0.0 if i < 5 or i > 14 else 0.3))["event"] for i in range(30)]
ok("speech start and end events come back from C++", ev.count("speech_start") == 1 and ev.count("speech_end") == 1)
ok("device command round trip", rt.set("light_living", {"level": 150})["applied"]["level"]["clamped"] is True)
rt.stop()

# ---------------- the Python server wiring everything together ----------------
from brain import server as S
class R:
    def __init__(s, status=200, data=None, lines=None, content=b""): s.status_code, s._d, s._l, s.content, s.headers, s.text = status, data, lines or [], content, {}, ""
    ok = property(lambda s: s.status_code < 400)
    def json(s): return s._d
    def iter_lines(s): return iter(s._l)
    def iter_content(s, n=0): yield s.content
CUS, N, LAST = {}, [0], {}
def fake(method, url, **kw):
    if "api.stripe.com" in url:
        path, pr = url.split("/v1")[1], kw.get("params") or kw.get("data") or {}
        if path == "/customers" and method == "GET": return R(data={"data": [c for c in CUS.values() if c["email"] == pr["email"]]})
        if path == "/customers" and method == "POST":
            N[0] += 1; cid = "cus_%d" % N[0]
            CUS[cid] = {"id": cid, "email": pr["email"], "name": pr["name"], "metadata": {k[9:-1]: v for k, v in pr.items() if k.startswith("metadata[")}}; return R(data=CUS[cid])
        if path.startswith("/customers/"): return R(data=CUS[path.split("/")[2]])
        if path == "/subscriptions": return R(data={"data": []})
    if "generativelanguage" in url:
        if "/models?" in url: return R(data={"models": [{"name": "models/gemini-2.5-flash", "supportedGenerationMethods": ["generateContent"]}]})
        if ":streamGenerateContent" in url:
            LAST["body"] = kw.get("json")
            return R(lines=[("data: " + json.dumps({"candidates": [{"content": {"parts": [{"text": t}]}}]})).encode() for t in ["Sure, ", "done."]])
    return R(404, {"error": "x"})
S.requests.get = lambda u, **k: fake("GET", u, **k); S.requests.post = lambda u, **k: fake("POST", u, **k); S.requests.request = lambda m, u, **k: fake(m, u, **k)
ok("server starts the C++ core", S.start_realtime())
S.time.sleep = lambda s: None        # skip the deliberate delay after a wrong password
c = S.app.test_client()
tok = c.post("/api/login", json={"id": "NeutronKingSwaransh", "password": "NeutronKingOP3699"}).get_json()["token"]
O = {"Authorization": "Bearer " + tok}
def chat(text, headers=O, mode="fast"):
    r = c.post("/api/chat", json={"mode": mode, "contents": [{"role": "user", "parts": [{"text": text}]}]}, headers=headers)
    r.get_data(); return r
def sysprompt(): return LAST["body"]["systemInstruction"]["parts"][0]["text"]
chat("Remember that my favourite colour is blue")
chat("hello again")
chat("what is my favourite colour?")
ok("a fact told earlier is recalled and given to the LLM (SQL -> Python -> prompt)", "favourite colour is blue" in sysprompt())
r = chat("turn off the light and set the thermostat to 25")
st = c.get("/api/devices", headers=O).get_json()
ok("owner chat controls devices through the C++ core", st["devices"]["light_living"]["props"]["on"]["value"] == 0 and st["devices"]["thermostat"]["props"]["setpoint"]["value"] == 25)
ok("the LLM is told what was done", "light_living" in sysprompt() and "done" in sysprompt())
chat("unlock the door")
ok("unlock without confirmation is refused and the LLM is told", "confirmation_required" in sysprompt() and c.get("/api/devices", headers=O).get_json()["devices"]["door_lock"]["props"]["locked"]["value"] == 1)
chat("unlock the door, confirmed")
ok("unlock with confirmation works", c.get("/api/devices", headers=O).get_json()["devices"]["door_lock"]["props"]["locked"]["value"] == 0)
chat("raise the arm")
chat("emergency stop")
chat("lower the arm")
st = c.get("/api/devices", headers=O).get_json()
ok("emergency stop is active and refuses robot motion", st["estop"] is True and "estop_active" in sysprompt())
ok("device actions are logged in SQL", len(st["log"]) >= 4)
ok("device endpoint rejects injection", c.post("/api/devices/set", json={"device": "light_living", "props": {"on": "1 confirm=1"}}, headers=O).status_code == 400)
ok("resume works", c.post("/api/devices/resume", json={}, headers=O).get_json()["estop"] is False)
# a normal user
ut = c.post("/api/signup", json={"id": "normal_1", "email": "n@x.co", "password": "password123"}).get_json()["token"]; U = {"Authorization": "Bearer " + ut}
chat("turn on the light", U)
ok("normal user's chat cannot move owner devices", c.get("/api/devices", headers=U).status_code == 403 and c.get("/api/devices", headers=O).get_json()["devices"]["light_living"]["props"]["on"]["value"] == 0)
chat("what is my favourite colour?", U)
ok("memory is private: a normal user does not get the owner's memories", "blue" not in sysprompt())
ok("memory API lists and searches", any("blue" in m["text"] for m in c.get("/api/memory?q=colour", headers=O).get_json()["memories"]) and c.get("/api/memory", headers=U).get_json()["memories"] != None)
mid = c.post("/api/memory", json={"text": "Dashboard note: buy bread"}, headers=U).get_json()["id"]
ok("memory note can be added and forgotten", c.post("/api/memory/delete", json={"id": mid}, headers=U).get_json()["ok"] and not any("bread" in m["text"] for m in c.get("/api/memory", headers=U).get_json()["memories"]))
pcm = tone(300, 0.4, 1600)
res = [c.post("/api/audio", data=pcm[i:i+640], headers={**O, "X-Sample-Rate": "16000", "Content-Type": "application/octet-stream"}).get_json() for i in range(0, len(pcm), 640)]
ok("audio endpoint streams PCM through C++ and returns spectrum + speech", res[-1]["speech"] is True and len(res[-1]["bands"]) == 8 and res[-1]["bands"][2] > 0.8)
ok("audio endpoint needs login", c.post("/api/audio", data=pcm[:640]).status_code == 401)
ok("system status shows all layers", (lambda j: j["brain"]["ok"] and j["realtime"]["ok"] and j["memory"]["memories"] >= 1)(c.get("/api/system", headers=O).get_json()))
ok("dashboard page is served", b"Jarvis dashboard" in c.get("/dashboard.html").data)
S.RTC.stop(); shutil.rmtree(TMP, ignore_errors=True)
print("\nALL PASSED" if not fails else "\nFAILED: %s" % fails)
sys.exit(1 if fails else 0)
