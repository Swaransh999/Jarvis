SETTING UP GOOGLE, META AND ADOBE SIGN-IN
==========================================

How it works: the sign-in buttons are already in the page. Each one switches on when its ID is filled in
inside keys.env. The server then checks every login token with the provider itself (including that it was
issued for YOUR app), so nobody can fake a login. Restart  python run.py  after editing keys.env.

Use these two addresses wherever a provider asks for your site:
   Testing on your computer:  http://localhost:5000
   Your live site:            https://YOUR-SITE   (no path, no slash at the end)

------------------------------------------------------------------------------------------------
1) GOOGLE   ->  GOOGLE_CLIENT_ID=
------------------------------------------------------------------------------------------------
 1. Open console.cloud.google.com and create (or pick) a project.
 2. Open "APIs & Services" > "OAuth consent screen" (newer layout: "Google Auth Platform").
    App name: Jarvis. Support email: yours. Audience: External.
    While the app is in "Testing", only people you add under "Test users" can sign in. Add your own email.
    Press "Publish app" when you want everyone to sign in (basic profile and email need no review).
 3. Open "Credentials" > "Create credentials" > "OAuth client ID" > Application type "Web application".
 4. Under "Authorized JavaScript origins" add BOTH addresses above. Leave "Authorized redirect URIs" empty.
 5. Copy the Client ID (it ends in .apps.googleusercontent.com) into keys.env:
        GOOGLE_CLIENT_ID=123456789-abc.apps.googleusercontent.com
 6. Restart the server and press the Google button.

------------------------------------------------------------------------------------------------
2) META (Facebook)   ->  META_APP_ID=
------------------------------------------------------------------------------------------------
 1. Open developers.facebook.com > "My Apps" > "Create app".
    Use case: "Authenticate and request data from users with Facebook Login". App name: Jarvis.
 2. "App settings" > "Basic": copy the App ID. Add your live domain under "App domains" and add a
    Privacy Policy URL (required before the app can go Live).
 3. "Facebook Login" > "Settings": turn ON "Client OAuth login", "Web OAuth login" and
    "Login with the JavaScript SDK". Under "Allowed domains for the JavaScript SDK" add your live site address.
 4. Put the App ID into keys.env:
        META_APP_ID=1234567890123456
 5. The app starts in Development mode: only you and people you add under "App roles" can sign in.
    Switch the toggle at the top of the dashboard to Live so everyone can.
 Facebook Login needs a secure (https) site. localhost is usually allowed while testing; if it refuses,
 test on your live https address.

------------------------------------------------------------------------------------------------
3) ADOBE   ->  ADOBE_CLIENT_ID=      (least certain: read the note)
------------------------------------------------------------------------------------------------
 1. Open developer.adobe.com/console > "Create new project".
 2. Add a credential of type "OAuth Web App" (Adobe ID sign-in).
 3. Default redirect URI:  https://YOUR-SITE/      Redirect URI pattern:  https://YOUR-SITE/.*
    (for testing also add http://localhost:5000/ and its pattern)
 4. Copy the Client ID into keys.env:
        ADOBE_CLIENT_ID=your-adobe-client-id
 NOTE: Adobe web-app credentials normally use a code exchange with a client secret. The page currently asks for a
 token directly, which Adobe may refuse. If the Adobe button fails, tell me what the Adobe console offers (and keep
 the client secret handy); the Python server makes the proper code exchange easy to add, and I can finish it.

------------------------------------------------------------------------------------------------
4) ANTHROPIC
------------------------------------------------------------------------------------------------
 As far as I know, Anthropic does not offer a public "Sign in with Anthropic" for other websites, so there is
 nothing to set up. That button explains this when pressed. If Anthropic publishes one, send me its details.

------------------------------------------------------------------------------------------------
CHECKING IT
------------------------------------------------------------------------------------------------
 * Log in first as the owner (ID NeutronKingSwaransh) to confirm the server works.
 * A provider whose ID is still empty shows "sign-in isn't set up on this site yet".
 * If someone signs in with Google/Meta/Adobe using an email that already has a Jarvis ID account, they are told to
   log in with the Jarvis ID instead (this stops others from taking over an account by registering your email first).
 * Open /api/health?deep=1 to see which keys and models the server is using.
